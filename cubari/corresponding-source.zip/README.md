# Cubari Site Publisher v0.20.0

## Experimental modified original Cubari reader

The supplied live API diagnostics returned HTTP 200 and 107/86/84 pages but no CORS permission for the configured GitHub Pages origin. Therefore the modified upstream frontend consumes static ordered URL manifests obtained from Cubari by the local Publisher, not direct ImgChest requests. No manga images are downloaded or hosted by the Publisher.

After updating, choose **Prepare Modified Cubari Reader (experimental)** in Dashboard. This resolves missing/changed manifests from Cubari and rebuilds preview. Open a long chapter to test the single exit link, settings, zoom and chapter navigation. A 40-page response (unless explicitly supplied as a direct list in the original chapter JSON), invalid response, multi-group release or missing list uses the existing embedded Cubari instead. The older embedded reader is the default until preparation is requested. **Use Embedded Cubari Only** restores it for all chapters without removing cached data. Repeat preparation after adding or changing chapters if you want the modified frontend for those chapters. No token or dependency changes.

The About category and ZIP-download action are removed only from the modified frontend. Source and attribution are linked in the catalogue footer. The fallback is the unmodified cross-origin iframe and still shows its original controls.

This is experimental: the browser environment blocked test navigation, so preview and verify before publishing. Do not treat all responses other than 40 as independently proven complete; known shorter-than-previous responses are rejected, but Cubari does not provide an independent expected count for every album.

The following sections describe the existing Publisher features; embedded-reader details apply to the fallback mode.


Standalone Pinokio app: read the existing Cubari Manga Library and Gist Helper data, cache MangaDex metadata and covers, generate a static catalogue, and publish it to the configured GitHub Pages repository.

## Update

1. Stop the Publisher. Extract the archive over `C:\pinokio\api\CubariSitePublisher`, replacing existing files. Do not delete `app\data` or the environment.
2. Start the app, hard-refresh the admin UI (Ctrl+F5), and click **Save & Generate Preview**.
3. Open a chapter in the preview, preferably in a normal browser tab rather than inside Pinokio's UI. Check a long chapter and the return links.
4. Check the organization repository in **Test GitHub Connection**, then **Publish Cached Data**. No dependency reinstall or metadata refresh is needed for the reader update.

## Original Cubari reader only

Every valid chapter opens the local `reader.html` wrapper (the older `cubari-reader.html` route remains compatible). It embeds the original Cubari.moe reader with a separate slim header, containing a catalogue exit and centered manga title link (no separate external Cubari button). The iframe is never shifted, covered or cropped. Sandbox permissions allow scripts, same-origin storage, forms and popups; fullscreen is allowed separately. Browser file downloads and top-level navigation are not granted. Cubari’s download menu remains visible and may still prepare a ZIP in memory, but sandboxed browser downloads are restricted. Manual image saving and direct visits to Cubari are not prevented. The app never automatically redirects the whole catalogue to Cubari. The actual reader, settings, chapter and page navigation are Cubari's own.

The custom Native and Hybrid readers, image-list refresh/repair endpoints, ImgChest views and ImgChest token UI have been removed. Existing legacy mode settings are ignored and stripped from newly saved settings. Existing cache files are left on disk during update; no old page lists are published. The generated-site manifest allows publishing to remove previously generated native reader assets.

**Optional:** Refresh Cubari Page Counts fetches the chapter's page-list response from Cubari, stores only a count/timestamp, and never downloads images or contacts ImgChest directly. Counts are snapshots, not live view counts. Responses of exactly 40 URLs are conservatively omitted because the earlier retrieval bug truncated long chapters to 40. Counts from explicit local JSON page arrays may also appear. Missing counts do not prevent reading or publishing. No views are displayed because Cubari does not expose a view count in its chapter response.

**Limitations:** Embedding depends on Cubari permitting frames and the browser's storage/framing policies. A cross-origin parent cannot reliably inspect the loaded Cubari document, read its current page, detect a framing denial or modify the original toolbar. If Cubari blocks framing, a static GitHub Pages site cannot override that policy. Live embedding was not verified in this environment.

## Catalogue and publishing

- Scan Local JSON reads existing app data without modifying it; refresh MangaDex metadata and covers when desired.
- Site Editor retains introduction formatting, tags and filters, accent, labels, chapter preview rows and chapter range groups.
- Chapter rows link only to your Cubari releases. No MangaDex chapter matching is required.
- The site is static; MangaDex requests are made during administrative refreshes, not by readers.
- A GitHub token can be saved locally in `app/data/credentials.json` and is not included in the generated site or update ZIP. Publishing uses the configured owner/repository and configured commit identity, not the token username as repository owner. GitHub activity metadata may still identify the authenticated account.
- Keep `app/data` intact. It stores configuration, source mappings, metadata, cached covers, optional counts, credentials and generated preview. Resetting the environment should not remove it. The explicit Clear Metadata & Counts Cache action clears cached data only.

See CHANGELOG.md for historical releases and TESTING.md for validation.
