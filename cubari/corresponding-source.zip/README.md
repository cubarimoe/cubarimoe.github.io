# Cubari Site Publisher v0.21.1

Standalone Pinokio publisher for a static GitHub Pages manga catalogue sourced from Cubari Gist Helper and Cubari Manga Library, with MangaDex metadata and covers cached at publication time.

## Update from v0.21.0

1. Stop the Publisher. Extract the ZIP over `C:\pinokio\api\CubariSitePublisher`, replacing existing files. Keep `app/data` and `app/env` intact.
2. Start and hard-refresh the admin UI (Ctrl+F5).
3. Use **Save & Generate Preview**. Prepared chapter manifests from v0.20.0 are reused automatically; the experimental opt-in is no longer needed.
4. Use **Refresh Cubari Reader Data** to retrieve edits to existing albums as well as new chapters. Check the preview before publishing.
5. Confirm the target organization repository with **Test GitHub Connection**, then use **Publish Cached Data** or **Refresh All & Publish**.

No dependency reinstall, credential re-entry or cache deletion is necessary. Reader refresh now makes one request per supported album and may take longer. If the temporary source collector was previously installed, its files `collect-cubari-source.js`, `app/collect_cubari_source.py`, and `READER_DIAGNOSTICS.md` are no longer used and may be deleted manually. The collector is not included in this update and has no Pinokio menu entry.

## Normal workflow

- **Scan Local JSON** reads both existing Cubari apps without modifying them.
- **Refresh All MangaDex Data** updates metadata and currently selected covers.
- **Refresh Cubari Reader Data** rechecks every supported album from Cubari, even if its local release date and URL are unchanged. Failed or suspicious responses preserve existing valid manifests. The Results tab lists changed page counts and errors. This action replaces the old experimental preparation and separate count refresh.
- **Save & Generate Preview** builds the static site without requesting chapter data or MangaDex again.
- **Publish Cached Data** regenerates and publishes using cached data only. **Refresh All & Publish** scans, refreshes MangaDex, refreshes Cubari manifests, generates, and publishes.

## Reader

The modified original Cubari frontend is always preferred when valid chapter data is available. It uses ordered image URLs retrieved from Cubari by the Publisher (not a direct ImgChest integration); it does not download or host manga images. Page counts come from the same manifest or explicit local page arrays. Existing valid legacy count snapshots may still supply a count for an unprepared chapter and protect against shorter-than-known responses, but there is no separate count refresh or new count cache writing. No views are retrieved or displayed.

The modified frontend retains Cubari's original layout, zoom, preloading, reading modes, themes and controls, with catalogue exit, title link, no chapter-download action, and no About tab. Attribution, license and corresponding source remain in the published footer.

An automatic embedded Cubari fallback remains for unavailable, suspect or unsupported manifests, including ambiguous 40-page responses and multi-group chapters. It is not a selectable reader mode. The fallback uses Cubari's unmodified controls (including its original exit and download menu entries), without cropping or masking. Browser file downloads and top-level navigation are not granted to the fallback iframe. Older `reader.html` and `cubari-reader.html` URLs remain supported. Cubari does not supply an independent expected page count for all albums, so the completeness check is conservative, not a guarantee.

## Catalogue and settings

- Site Editor retains introduction formatting, accent, labels, tags, filters, chapter preview rows and chapter range groups.
- Existing manga mappings, metadata, covers, credentials and reader manifests are preserved. Retired mode flags are removed from configuration on load.
- The public website makes no MangaDex requests. It lists only your Cubari releases.
- Local GitHub token storage is optional. The generated site contains no saved token. Publication uses the configured owner/repository and neutral commit identity; GitHub activity metadata may still identify the authenticated user.
- Reset Environment preserves persistent data. The explicit **Clear Metadata & Reader Cache** action removes cached metadata, covers, reader manifests and any old cache files. Do not use it just to upgrade.

See CHANGELOG.md for historical releases and TESTING.md for validation details.
