# v0.21.1 — Refresh existing chapter edits

- Manual reader refresh and full publication recheck all supported albums even when the local release timestamp is unchanged.
- Compare ordered page URL arrays, report new/updated/unchanged lists and old/new counts; retain good cached data on failed or suspicious responses.
- Full publication asks for confirmation when refresh errors occur. Cached publication still performs no refresh.
- Revalidate browser manifest requests and version the modified reader script.
- No dependency or persistent configuration changes.

# v0.21.0 — cleanup

- Modified original Cubari frontend is the default and only primary reader; removed experimental mode flag and embedded-only switch, plus their obsolete UI/backend paths.
- Unified reader preparation and page-count retrieval into one refresh. Existing manifests remain compatible; no duplicate count requests or new count-cache writes. Legacy counts are read only for existing metadata/completeness hints.
- Full refresh and publish now includes reader data; cached publication remains offline with respect to chapter data and metadata.
- Updated dashboard, status, Site Editor and publication workflow text, cache menu and documentation. Existing mode flags are removed safely from config on load.
- Automatic embedded safety fallback and historical reader URLs retained. Original modified frontend assets and license/source bundle unchanged.
- No cache deletion or dependency changes during update.

## v0.20.0 — Experimental modified upstream Cubari frontend

- Use original Cubari HTML/CSS/JS with a static data adapter for GitHub Pages.
- Single catalogue exit; remove chapter ZIP download and About category from modified frontend.
- Prepare ordered URL manifests via Cubari; keep existing iframe for unavailable/suspicious data.
- Opt-in preparation and one-click rollback to embedded only.
- Preserve upstream AGPL license, credits and corresponding source.
- No dependencies changed.

## v0.19.2 — Restrict embedded reader downloads

- Removed `allow-downloads` from the shared Cubari iframe sandbox. Both reader routes retain scripts, forms, same-origin access, popups and fullscreen.
- Cubari’s own download menu remains visible; this is a browser download restriction, not a modification of its internal code.
- No cache or dependency changes.

## v0.19.1 — Cleaner embedded reader header

- Remove the website-owned Open in Cubari link and its JavaScript/CSS.
- Center the manga title using equal-width side columns; preserve the catalogue exit and unchanged iframe.

## v0.19.0 — Cubari-only reader

- Remove Native and Hybrid mode, local image-list verification and direct ImgChest views/token workflow.
- All valid chapter cards link to a local embedded-reader wrapper; preserve old wrapper URLs.
- Restrict frame navigation to prevent automatic top-level redirects; keep explicit external fallback.
- Optional Cubari-only page-count refresh, independent of reading or publishing.
- Preserve legacy local data and remove obsolete generated native reader assets on republish.

# Changelog

## 0.18.0
- Original Cubari iframe is the default reader. Separate return bar, responsive non-overlapping layout, external fallback link, original Cubari controls.
- Site Editor choice of Embedded, Native or Hybrid. Previous native reader and caches retained.
- Embedded chapters need no page-list cache, publish no page lists, and do not display potentially misleading cached page counts.
- Hybrid embeds unverified chapters; Native keeps prior safeguards. Existing native reader URLs redirect to the embedded reader when selected.
- Independent ImgChest view snapshots; embedded full update skips native page retrieval. Existing settings/credentials untouched.
- 23 offline tests passed; mock-frame layout checked at five sizes; actual Cubari network/frame behavior not verified.

## 0.17.0
- Optional session-only ImgChest API token for exact count verification and ordered complete page lists.
- Display unresolved chapter details directly on Dashboard; persist sanitized verification failures for missing caches.
- Keep the existing anonymous fallback and incomplete-page safeguards. No dependencies changed.

## 0.16.0

- Detects legacy 40-page cache entries and verifies complete page lists against ImgChest counts and Cubari chapter JSON.
- Adds targeted repair, ordered page preservation, retries, stale-cache protection, diagnostics and publication warnings.
- Unverified native chapter lists fall back to the original Cubari link instead of presenting a truncated chapter.
- Preserves v0.15.0 GitHub initialization and prior reader/catalogue features.

## 0.15.0

- Fixed first publication to a completely empty GitHub repository.
- Added documented Repository Contents API initialization before using raw Git Database endpoints.
- Reused a real generated site file for the bootstrap commit, avoiding leftover placeholder files.
- Preserved the neutral configured author and committer identity on both first-publication commits.
- Added a retry without an explicit branch for newly-created repositories whose default branch is still settling.
- Added a clear retry message if GitHub accepts initialization but the branch is not immediately available.
- Updated app and network user-agent versions to 0.15.

## 0.14.0

- Removed the duplicated lower chapter-card chevron and its empty second row.
- Tightened chapter-card height, padding, and arrow sizing.
- Added BookWalker URL normalization for MangaDex's relative `series/{id}` values.
- Added a generation-time migration that repairs existing cached links without requiring a MangaDex refresh.
- Unknown and unsupported MangaDex link codes (including `bl`) are now omitted, even when an old cache contains a localhost URL.
- Reader pages are hidden until their fitted zoom size has been applied, preventing the large-image-then-rescale flash.
- The current and adjacent reader pages are preloaded, with the current page fetched before the reader is revealed.
- Updated app and network user-agent versions to 0.14.

## 0.13.0

- Moved Description, Alternative titles, and External links above the Cubari releases section.
- Replaced the always-expanded chapter list with a configurable recent-chapter preview in a two-column grid.
- Added chapter search and newest/oldest sorting.
- Added Show all / Show recent chapter controls.
- Added Jump to chapter ranges for series with hundreds or thousands of releases.
- Added configurable recent rows and chapter-range size under Site Editor.
- Cached ImageChest post view counts alongside native-reader page lists and optionally displayed them on chapter cards.
- Made the manual Refresh Reader Pages action force a current ImageChest snapshot.
- Added a 24-hour freshness window for automatic publish-time reader-cache and view-stat refreshes.
- Updated app and network user-agent versions to 0.13.

## 0.12.0

- Reduced the native reader toolbar from roughly 122 px to about 88 px on desktop, with still smaller landscape-phone sizing.
- Reworked desktop toolbar positioning so the manga/chapter heading is centered independently of the exit and action controls.
- Added automatic reader-control hiding after approximately 2.6 seconds of inactivity.
- Added a upper-area hover detection that restores hidden controls without leaving a permanent blank bar.
- Added full-reader left, middle, and right click/tap zones for previous page, control visibility, and next page.
- Made the three-zone navigation work in both Single and Strip modes while ignoring buttons and links.
- Fixed zoom controls by sizing images from their natural dimensions and current viewport rather than changing an ineffective CSS maximum width.
- Made 100% zoom mean fit-to-viewport in Single mode and fit-to-width in Strip mode, with functional 50–200% scaling and scrollable enlarged pages.
- Added resize-aware zoom recalculation and center preservation.
- Added `M` as a keyboard shortcut to show or hide reader controls.
- Kept zoom-out and zoom-in controls available on narrow mobile layouts.
- Updated app and network user-agent versions to 0.12.

## 0.11.0

- Replaced the cross-origin Cubari iframe with an original native static manga reader.
- Removed all iframe header-cover, offset, and responsive guessing logic.
- Added ImageChest album detection for every chapter read from Cubari Gist Helper JSON.
- Added publication-time ImageChest page-list resolution using the same post-data structure handled by Cubari's open-source ImageChest source.
- Added persistent chapter page-list caching under `app/data/cache/reader_pages`.
- Added a **Refresh Reader Pages** workflow action and cache status display.
- Added automatic reader-page refresh to the complete refresh-and-publish workflow.
- Added `reader.html` with strip and single-page modes, zoom, fullscreen, page/chapter navigation, keyboard controls, touch swipes, and local reading progress.
- Kept Cubari as a fallback only when a chapter page list or remote image cannot be loaded.
- Removed the obsolete embedded-header cover-height setting.
- Updated the cache-clearing Pinokio action to include native-reader page lists.
- Updated app and network user-agent versions to 0.11.

## 0.10.0

- Hardened the website-owned Cubari header cover for desktop, tablets, portrait phones, landscape phones, narrow/zoomed layouts, and notched displays.
- Added CSS safe-area support for top, left, and right display cutouts.
- Added `100vh` plus `100dvh` fallbacks for older and modern mobile browsers.
- Added responsive minimum cover heights instead of relying on only one desktop/mobile breakpoint.
- Added a configurable **Website header cover height** field under Site Editor → Embedded reader.
- Moved **Reader not loading?** from the manga-image area into the website-owned top header.
- On narrow screens, the fallback becomes a compact external-open icon with an explanatory tooltip and accessible label.
- Removed the old floating reader-help panel entirely.
- Updated app version and GitHub/MangaDex user agents to 0.10.0.

## 0.9.0

- Added an opaque website-owned cover over Cubari's internal top title area.
- Added a left-side × link back to the catalogue.
- Made the displayed manga title link back to the website manga page.
- Removed the separate top-right reader close button.
- Preserved Escape-to-close behavior and direct-new-tab chapter fallback.
- Repositioned “Reader not loading?” to the lower-right corner.

## 0.8.0

- Made each complete Cubari chapter row clickable.
- Added a full-screen embedded Cubari reader overlay to generated title pages.
- Added optional local GitHub token storage and token-expiration/status display.

## 0.7.0

- Added safe Markdown links, bold, italics and line breaks to the Introduction field.
- Added formatting buttons, tooltip help and live preview.

## 0.6.0

- Restored static MangaDex-tag filtering.
- Added exact per-chapter Cubari links and kept MangaDex title-level only.
- Removed Gist Helper credential-path handling.
