from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import quote

from chapter_pages import extract_imgchest_id
from storage import LIBRARY_FILE, MAPPINGS_FILE, load_json, save_json

UUID_RE = re.compile(
    r"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})"
)


def _norm(text: Any) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _title_key(text: Any) -> str:
    value = unicodedata.normalize("NFKC", _norm(text)).casefold()
    return re.sub(r"[^\w]+", "", value, flags=re.UNICODE)


def _slug(text: str) -> str:
    value = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return value or "title"


def _stable_id(identity: str) -> str:
    raw = _norm(identity).casefold().encode("utf-8", errors="ignore")
    return hashlib.sha1(raw).hexdigest()[:16]


def _parse_time(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, (int, float)):
        number = int(value)
        if number > 10_000_000_000:
            number //= 1000
        return max(number, 0)
    text = str(value).strip()
    if not text:
        return 0
    if text.isdigit():
        return _parse_time(int(text))
    normalized = text.replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(normalized)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp())
    except ValueError:
        return 0


def _first_value(obj: dict[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        value = obj.get(key)
        if value not in (None, "", [], {}):
            return value
    return None


def _natural_number(value: str) -> tuple[tuple[int, Any], ...]:
    parts = re.findall(r"\d+|[A-Za-z]+", str(value))
    if not parts:
        return ((2, str(value).casefold()),)
    return tuple((0, int(part)) if part.isdigit() else (1, part.casefold()) for part in parts)


def _normalize_raw_source(raw_url: str) -> str:
    raw_url = raw_url.strip()
    prefixes = {
        "https://raw.githubusercontent.com/": "raw/",
        "http://raw.githubusercontent.com/": "raw/",
        "https://gist.githubusercontent.com/": "gist/",
        "http://gist.githubusercontent.com/": "gist/",
    }
    for prefix, replacement in prefixes.items():
        if raw_url.startswith(prefix):
            return replacement + raw_url[len(prefix) :]
    return raw_url


def cubari_url_from_raw(raw_url: str) -> str:
    if not raw_url:
        return ""
    source = _normalize_raw_source(raw_url)
    encoded = base64.b64encode(source.encode("utf-8")).decode("ascii")
    return f"https://cubari.moe/read/gist/{quote(encoded, safe='')}/"


def _mangadex_id(value: Any) -> str:
    match = UUID_RE.search(str(value or ""))
    return match.group(1).lower() if match else ""


def _new_record(title: str) -> dict[str, Any]:
    return {
        "title": _norm(title),
        "description": "",
        "author": "",
        "artist": "",
        "cover": "",
        "cubari_url": "",
        "raw_url": "",
        "mangadex_id": "",
        "chapter_count": 0,
        "chapters": [],
        "latest_chapter": {},
        "last_updated": 0,
        "source_mtime": 0,
        "source_file": "",
        "source_files": [],
        "source_types": [],
        "in_manga_library": False,
        "library_entries": [],
        "history": {},
        "qrcode": {},
    }


def _add_source(record: dict[str, Any], source_file: Path | str, source_type: str) -> None:
    source_text = str(source_file) if source_file else ""
    if source_text:
        files = record.setdefault("source_files", [])
        if source_text not in files:
            files.append(source_text)
        if not record.get("source_file"):
            record["source_file"] = source_text
        try:
            path = Path(source_text)
            if path.exists():
                record["source_mtime"] = max(int(record.get("source_mtime") or 0), int(path.stat().st_mtime))
        except OSError:
            pass
    types = record.setdefault("source_types", [])
    if source_type and source_type not in types:
        types.append(source_type)


def _parse_chapters(chapters: Any) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    if isinstance(chapters, dict):
        items = chapters.items()
    elif isinstance(chapters, list):
        items = enumerate(chapters, start=1)
    else:
        return result

    for chapter_key, value in items:
        if not isinstance(value, dict):
            value = {"title": str(value)}
        number = _norm(_first_value(value, ("chapter", "number", "chapter_number"))) or str(chapter_key)
        groups = value.get("groups")
        group_count = len(groups) if isinstance(groups, dict) else 0
        source = ""
        direct_pages: list[str] = []
        if isinstance(groups, dict) and groups:
            first_value = next(iter(groups.values()))
            if isinstance(first_value, str):
                source = first_value.strip()
            elif isinstance(first_value, list):
                direct_pages = [str(page).strip() for page in first_value if str(page).strip()]
            elif isinstance(first_value, dict):
                maybe_pages = first_value.get("pages") or first_value.get("images") or []
                if isinstance(maybe_pages, list):
                    direct_pages = [str(page).strip() for page in maybe_pages if str(page).strip()]
                source = str(first_value.get("source") or first_value.get("url") or "").strip()
        elif isinstance(groups, list):
            direct_pages = [str(page).strip() for page in groups if str(page).strip()]
        result.append(
            {
                "number": number,
                "title": _norm(_first_value(value, ("title", "name", "chapter_title"))),
                "volume": _norm(_first_value(value, ("volume", "vol"))),
                "last_updated": _parse_time(
                    _first_value(value, ("last_updated", "updated_at", "timestamp", "date", "created_at"))
                ),
                "group_count": group_count,
                "reader_source": source,
                "imgchest_id": extract_imgchest_id(source),
                "pages": direct_pages,
            }
        )
    result.sort(key=lambda item: (_natural_number(item["number"]), item["number"]))
    return result


def _latest_chapter(chapters: list[dict[str, Any]]) -> dict[str, Any]:
    if not chapters:
        return {}
    with_dates = [item for item in chapters if int(item.get("last_updated") or 0) > 0]
    if with_dates:
        return max(with_dates, key=lambda item: int(item.get("last_updated") or 0))
    return chapters[-1]


def _resolve_data_dir(raw_path: str, markers: tuple[str, ...]) -> Path | None:
    if not raw_path:
        return None
    path = Path(raw_path).expanduser()
    if path.is_file():
        path = path.parent
    candidates = [path, path / "data", path / "app" / "data"]
    if path.name.casefold() == "data":
        candidates.extend([path.parent / "data", path.parent / "app" / "data"])

    ranked: list[tuple[int, int, Path]] = []
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate).casefold()
        if key in seen or not candidate.is_dir():
            continue
        seen.add(key)
        marker_score = sum(1 for marker in markers if (candidate / marker).exists())
        json_count = sum(1 for _ in candidate.glob("*.json"))
        ranked.append((marker_score, json_count, candidate))
    if not ranked:
        return None
    ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return ranked[0][2]


def _load_json_file(path: Path, default: Any, errors: list[dict[str, str]]) -> Any:
    try:
        with path.open("r", encoding="utf-8-sig") as handle:
            return json.load(handle)
    except Exception as exc:
        errors.append({"path": str(path), "error": str(exc)})
        return default


def _parse_gist_helper(raw_path: str, errors: list[dict[str, str]]) -> tuple[dict[str, dict[str, Any]], dict[str, int], Path | None]:
    data_dir = _resolve_data_dir(raw_path, ("history.json", "manga"))
    records: dict[str, dict[str, Any]] = {}
    counts = {"manga_jsons": 0, "history_entries": 0}
    if not data_dir:
        if raw_path:
            errors.append({"path": raw_path, "error": "Cubari Gist Helper data folder was not found"})
        return records, counts, None

    manga_dir = data_dir / "manga"
    if manga_dir.is_dir():
        for manga_file in sorted(manga_dir.glob("*.json")):
            payload = _load_json_file(manga_file, {}, errors)
            if not isinstance(payload, dict):
                continue
            title = _norm(_first_value(payload, ("title", "name", "manga_title")))
            chapters = _parse_chapters(payload.get("chapters"))
            if not title or not chapters:
                continue
            key = _title_key(title)
            record = records.setdefault(key, _new_record(title))
            record.update(
                {
                    "title": title,
                    "description": _norm(payload.get("description")),
                    "author": _norm(payload.get("author")),
                    "artist": _norm(payload.get("artist")),
                    "cover": _norm(payload.get("cover")),
                    "chapters": chapters,
                    "chapter_count": len(chapters),
                    "latest_chapter": _latest_chapter(chapters),
                }
            )
            record["last_updated"] = int((record.get("latest_chapter") or {}).get("last_updated") or 0)
            record["mangadex_id"] = _mangadex_id(record.get("cover"))
            record["identity_hint"] = manga_file.name
            _add_source(record, manga_file, "gist_manga_json")
            counts["manga_jsons"] += 1

    history_path = data_dir / "history.json"
    history = _load_json_file(history_path, {}, errors) if history_path.exists() else {}
    if isinstance(history, dict):
        for title, entry in history.items():
            if not isinstance(entry, dict):
                continue
            title = _norm(title)
            if not title:
                continue
            key = _title_key(title)
            record = records.setdefault(key, _new_record(title))
            record["title"] = record.get("title") or title
            for field in ("description", "author", "artist", "cover"):
                value = _norm(entry.get(field))
                if value:
                    record[field] = value
            raw_url = _norm(entry.get("raw_url"))
            if raw_url:
                record["raw_url"] = raw_url
                record["cubari_url"] = cubari_url_from_raw(raw_url)
            filename = _norm(entry.get("filename"))
            if filename:
                record["identity_hint"] = filename
            md_id = _mangadex_id(entry.get("mangadex_id")) or _mangadex_id(entry.get("cover"))
            if md_id:
                record["mangadex_id"] = md_id
            history_update = _parse_time(entry.get("latest_update"))
            record["last_updated"] = max(int(record.get("last_updated") or 0), history_update)
            history_latest = _norm(entry.get("latest_chapter"))
            if history_latest:
                match = next((ch for ch in record.get("chapters", []) if ch.get("number") == history_latest), None)
                if match and history_update >= int((record.get("latest_chapter") or {}).get("last_updated") or 0):
                    record["latest_chapter"] = dict(match)
                elif not record.get("latest_chapter"):
                    record["latest_chapter"] = {
                        "number": history_latest,
                        "title": "",
                        "volume": "",
                        "last_updated": history_update,
                        "group_count": 0,
                    }
            record["history"] = {
                "filename": filename,
                "latest_chapter": history_latest,
                "latest_update": history_update,
                "scanlation_status": _norm(entry.get("scanlation_status")),
                "md_publication_status": _norm(entry.get("md_publication_status")),
            }
            _add_source(record, history_path, "gist_history")
            counts["history_entries"] += 1

    return records, counts, data_dir


def _parse_manga_library(raw_path: str, errors: list[dict[str, str]]) -> tuple[dict[str, dict[str, Any]], dict[str, int], Path | None]:
    data_dir = _resolve_data_dir(raw_path, ("MangaLibrary.json", "QRCodes.json"))
    records: dict[str, dict[str, Any]] = {}
    counts = {"library_files": 0, "library_entries": 0, "qrcode_entries": 0}
    if not data_dir:
        if raw_path:
            errors.append({"path": raw_path, "error": "Cubari Manga Library data folder was not found"})
        return records, counts, None

    qrcodes_path = data_dir / "QRCodes.json"
    qrcodes = _load_json_file(qrcodes_path, {}, errors) if qrcodes_path.exists() else {}
    if isinstance(qrcodes, dict):
        for title, entry in qrcodes.items():
            if not isinstance(entry, dict):
                continue
            title = _norm(title)
            if not title:
                continue
            key = _title_key(title)
            record = records.setdefault(key, _new_record(title))
            gist_link = _norm(entry.get("gist_link"))
            if gist_link:
                record["cubari_url"] = gist_link
            record["qrcode"] = {
                "gist_link": gist_link,
                "qr_file": _norm(entry.get("qr_file")),
                "imgchest_link": _norm(entry.get("imgchest_link")),
                "cubari_proxy": _norm(entry.get("cubari_proxy")),
            }
            _add_source(record, qrcodes_path, "manga_library_qrcodes")
            counts["qrcode_entries"] += 1

    ignored_names = {"qrcodes.json", "theme_settings.json", "settings.json", "credentials.json"}
    for library_file in sorted(data_dir.glob("*.json")):
        if library_file.name.casefold() in ignored_names:
            continue
        payload = _load_json_file(library_file, {}, errors)
        if not isinstance(payload, dict) or not isinstance(payload.get("chapters"), dict):
            continue
        # Manga Library deliberately stores each manga as a chapter of the
        # library JSON. Do not interpret the library itself as a manga title.
        entries = payload.get("chapters") or {}
        recognized = 0
        for order_key, entry in entries.items():
            if not isinstance(entry, dict):
                continue
            title = _norm(entry.get("title"))
            if not title:
                continue
            key = _title_key(title)
            record = records.setdefault(key, _new_record(title))
            update = _parse_time(entry.get("last_updated"))
            record["last_updated"] = max(int(record.get("last_updated") or 0), update)
            record["in_manga_library"] = True
            record.setdefault("library_entries", []).append(
                {
                    "library_file": str(library_file),
                    "library_title": _norm(payload.get("title")),
                    "order": str(order_key),
                    "last_updated": update,
                }
            )
            _add_source(record, library_file, "manga_library_catalog")
            counts["library_entries"] += 1
            recognized += 1
        if recognized:
            counts["library_files"] += 1

    return records, counts, data_dir


def _merge_records(primary: dict[str, Any], secondary: dict[str, Any]) -> dict[str, Any]:
    if not primary:
        return secondary
    for field in ("description", "author", "artist", "cover", "cubari_url", "raw_url", "mangadex_id", "identity_hint"):
        if not primary.get(field) and secondary.get(field):
            primary[field] = secondary[field]
    if int(secondary.get("chapter_count") or 0) > int(primary.get("chapter_count") or 0):
        primary["chapters"] = secondary.get("chapters") or []
        primary["chapter_count"] = int(secondary.get("chapter_count") or 0)
        primary["latest_chapter"] = secondary.get("latest_chapter") or {}
    elif not primary.get("latest_chapter") and secondary.get("latest_chapter"):
        primary["latest_chapter"] = secondary["latest_chapter"]
    primary["last_updated"] = max(int(primary.get("last_updated") or 0), int(secondary.get("last_updated") or 0))
    primary["source_mtime"] = max(int(primary.get("source_mtime") or 0), int(secondary.get("source_mtime") or 0))
    primary["in_manga_library"] = bool(primary.get("in_manga_library") or secondary.get("in_manga_library"))
    primary["source_files"] = sorted(set((primary.get("source_files") or []) + (secondary.get("source_files") or [])))
    primary["source_types"] = sorted(set((primary.get("source_types") or []) + (secondary.get("source_types") or [])))
    primary["library_entries"] = (primary.get("library_entries") or []) + (secondary.get("library_entries") or [])
    if secondary.get("history"):
        primary["history"] = secondary["history"]
    if secondary.get("qrcode"):
        primary["qrcode"] = secondary["qrcode"]
        if secondary["qrcode"].get("gist_link"):
            primary["cubari_url"] = secondary["qrcode"]["gist_link"]
    if not primary.get("source_file"):
        primary["source_file"] = secondary.get("source_file", "")
    return primary


def _finalize_record(record: dict[str, Any]) -> dict[str, Any]:
    title = _norm(record.get("title")) or "Untitled"
    identity = record.get("identity_hint") or record.get("raw_url") or title
    title_id = _stable_id(str(identity))
    chapters = record.get("chapters") or []
    latest = record.get("latest_chapter") or _latest_chapter(chapters)
    local_update = max(
        int(record.get("last_updated") or 0),
        int((latest or {}).get("last_updated") or 0),
    )
    record.update(
        {
            "id": title_id,
            "slug": f"{_slug(title)}-{title_id[:6]}",
            "title": title,
            "chapter_count": len(chapters) if chapters else int(record.get("chapter_count") or 0),
            "latest_chapter": latest or {},
            "last_updated": local_update,
            "source_files": sorted(set(record.get("source_files") or [])),
            "source_types": sorted(set(record.get("source_types") or [])),
        }
    )
    if not record.get("cubari_url") and record.get("raw_url"):
        record["cubari_url"] = cubari_url_from_raw(record["raw_url"])
    if not record.get("mangadex_id"):
        record["mangadex_id"] = _mangadex_id(record.get("cover"))
    return record


def sync_imported_mappings(library: dict[str, Any]) -> dict[str, int]:
    mappings = load_json(MAPPINGS_FILE, {})
    if not isinstance(mappings, dict):
        mappings = {}
    added = updated = preserved_manual = 0
    changed = False
    for title in library.get("titles") or []:
        title_id = title.get("id")
        md_id = _mangadex_id(title.get("mangadex_id"))
        if not title_id or not md_id:
            continue
        current = mappings.get(title_id)
        if current is None:
            mappings[title_id] = {
                "mangadex_id": md_id,
                "selected_title": title.get("title", ""),
                "excluded": False,
                "title_override": "",
                "description_override": "",
                "mapping_source": "gist_helper",
            }
            added += 1
            changed = True
            continue
        source = current.get("mapping_source")
        if source == "manual" or (not source and current.get("mangadex_id")):
            preserved_manual += 1
            continue
        if current.get("mangadex_id") != md_id or source != "gist_helper":
            current["mangadex_id"] = md_id
            current["selected_title"] = current.get("selected_title") or title.get("title", "")
            current["mapping_source"] = "gist_helper"
            mappings[title_id] = current
            updated += 1
            changed = True
    if changed:
        save_json(MAPPINGS_FILE, mappings)
    return {"added": added, "updated": updated, "preserved_manual": preserved_manual}


def scan_source_paths(paths: list[str]) -> dict[str, Any]:
    manga_library_path = paths[0] if len(paths) > 0 else ""
    gist_helper_path = paths[1] if len(paths) > 1 else ""
    errors: list[dict[str, str]] = []

    gist_records, gist_counts, gist_data_dir = _parse_gist_helper(gist_helper_path, errors)
    library_records, library_counts, library_data_dir = _parse_manga_library(manga_library_path, errors)

    combined: dict[str, dict[str, Any]] = {}
    for source in (gist_records, library_records):
        for key, record in source.items():
            combined[key] = _merge_records(combined.get(key, {}), record)

    titles = [_finalize_record(record) for record in combined.values() if _norm(record.get("title"))]
    titles.sort(key=lambda item: item["title"].casefold())
    library = {
        "scanned_at": int(datetime.now(tz=timezone.utc).timestamp()),
        "files_seen": (
            int(gist_counts.get("manga_jsons") or 0)
            + int(library_counts.get("library_files") or 0)
            + (1 if gist_counts.get("history_entries") else 0)
            + (1 if library_counts.get("qrcode_entries") else 0)
        ),
        "titles": titles,
        "errors": errors,
        "sources": {
            "gist_helper_data": str(gist_data_dir) if gist_data_dir else "",
            "manga_library_data": str(library_data_dir) if library_data_dir else "",
            **gist_counts,
            **library_counts,
        },
    }
    save_json(LIBRARY_FILE, library)
    library["mapping_import"] = sync_imported_mappings(library)
    return library


def load_library() -> dict[str, Any]:
    return load_json(
        LIBRARY_FILE,
        {"titles": [], "errors": [], "files_seen": 0, "scanned_at": 0, "sources": {}},
    )


def detect_pinokio_sources(pinokio_home: str = "") -> dict[str, str]:
    root = Path(pinokio_home or os.environ.get("PINOKIO_HOME", r"C:\pinokio")) / "api"
    result = {"manga_library": "", "gist_helper": "", "goldmine_finder": ""}
    if not root.is_dir():
        return result

    def normalized_name(path: Path) -> str:
        return re.sub(r"[^a-z0-9]+", "", path.name.casefold())

    for child in root.iterdir():
        if not child.is_dir():
            continue
        name = normalized_name(child)
        if not result["manga_library"] and "cubari" in name and "manga" in name and "library" in name:
            data_dir = _resolve_data_dir(str(child), ("MangaLibrary.json", "QRCodes.json"))
            result["manga_library"] = str(data_dir or child)
        if not result["gist_helper"] and "cubari" in name and "gist" in name and "helper" in name:
            data_dir = _resolve_data_dir(str(child), ("history.json", "manga"))
            result["gist_helper"] = str(data_dir or child)
        if not result["goldmine_finder"] and "goldmine" in name and "finder" in name:
            result["goldmine_finder"] = str(child)

    return result
