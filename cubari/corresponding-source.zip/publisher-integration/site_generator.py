from __future__ import annotations

import html
import re
import shutil
from collections import Counter
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote, urlsplit, urlunsplit

from chapter_pages import load_cubari_count, load_reader_pages
from pathlib import Path
from mangadex import load_cached_metadata
from storage import COVERS_DIR, GENERATED_DIR, save_json


def _display_date(timestamp: int) -> str:
    if not timestamp:
        return "Unknown"
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).strftime("%B %d, %Y")


def _clean_tags(values: list[Any]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        tag = str(value).strip()
        key = tag.casefold()
        if tag and key not in seen:
            seen.add(key)
            result.append(tag)
    return result


_SAFE_LINK_RE = re.compile(
    r"\[([^]\n]+)\]\(((?:https?://|mailto:)[^\s<>'\")]+)\)",
    flags=re.IGNORECASE,
)


def _format_inline_markdown(value: str) -> str:
    escaped = html.escape(value)
    escaped = re.sub(r"\*\*([^*\n]+?)\*\*", r"<strong>\1</strong>", escaped)
    escaped = re.sub(r"(?<!\*)\*([^*\n]+?)\*(?!\*)", r"<em>\1</em>", escaped)
    return escaped


def _render_safe_markdown(value: str) -> str:
    """Render the small, intentionally limited Markdown subset used by site text.

    Raw HTML is escaped. Only http(s) and mailto links are made clickable.
    Supported formatting: **bold**, *italic*, [label](URL), and line breaks.
    """
    text = str(value or "").replace("\r\n", "\n").replace("\r", "\n")
    pieces: list[str] = []
    cursor = 0
    for match in _SAFE_LINK_RE.finditer(text):
        pieces.append(_format_inline_markdown(text[cursor : match.start()]))
        label = _format_inline_markdown(match.group(1))
        href = html.escape(match.group(2), quote=True)
        pieces.append(
            f'<a href="{href}" target="_blank" rel="noopener noreferrer">{label}</a>'
        )
        cursor = match.end()
    pieces.append(_format_inline_markdown(text[cursor:]))
    return "".join(pieces).replace("\n", "<br>\n")


def _chapter_cubari_url(series_url: str, chapter_number: str) -> str:
    number = str(chapter_number or "").strip()
    try:
        parsed = urlsplit(str(series_url or "").strip())
        if (parsed.scheme != "https" or parsed.netloc.lower() != "cubari.moe"
                or not re.fullmatch(r"/read/[^/]+/[^/]+/?", parsed.path) or not number):
            return ""
        return urlunsplit(("https", "cubari.moe", f"{parsed.path.rstrip('/')}/{quote(number, safe='')}/1/", "", ""))
    except ValueError:
        return ""



def _normalize_external_links(values: Any) -> dict[str, str]:
    """Repair and whitelist MangaDex external links.

    MangaDex stores several integrations as IDs or relative paths. Older
    generated previews could resolve those values against ``127.0.0.1`` or the
    Pages site itself. Unknown link codes are intentionally omitted.
    """
    if not isinstance(values, dict):
        return {}

    aliases = {
        "bookwalker": "BookWalker",
        "bw": "BookWalker",
        "mangaupdates": "MangaUpdates",
        "mu": "MangaUpdates",
        "myanimelist": "MyAnimeList",
        "mal": "MyAnimeList",
        "anilist": "AniList",
        "al": "AniList",
        "anime-planet": "Anime-Planet",
        "animeplanet": "Anime-Planet",
        "ap": "Anime-Planet",
        "kitsu": "Kitsu",
        "kt": "Kitsu",
        "amazon": "Amazon",
        "amz": "Amazon",
        "ebookjapan": "ebookjapan",
        "ebj": "ebookjapan",
        "novelupdates": "NovelUpdates",
        "nu": "NovelUpdates",
        "cdjapan": "CDJapan",
        "cdj": "CDJapan",
        "official raw": "Official Raw",
        "raw": "Official Raw",
        "official english": "Official English",
        "engtl": "Official English",
    }
    prefixes = {
        "BookWalker": "https://bookwalker.jp/",
        "MangaUpdates": "https://www.mangaupdates.com/series/",
        "MyAnimeList": "https://myanimelist.net/manga/",
        "AniList": "https://anilist.co/manga/",
        "Anime-Planet": "https://www.anime-planet.com/manga/",
        "Kitsu": "https://kitsu.io/manga/",
        "NovelUpdates": "https://www.novelupdates.com/series/",
        "CDJapan": "https://www.cdjapan.co.jp/",
    }

    result: dict[str, str] = {}
    for raw_label, raw_url in values.items():
        key = str(raw_label or "").strip().casefold()
        label = aliases.get(key)
        url = str(raw_url or "").strip()
        if not label or not url:
            continue

        # Repair BookWalker links already polluted by an old local-preview base,
        # e.g. http://127.0.0.1:42003/site/series/236718/list.
        if label == "BookWalker":
            match = re.search(r"(?:^|/)(series/[^?#]+)", url, flags=re.IGNORECASE)
            if match:
                url = "https://bookwalker.jp/" + match.group(1).lstrip("/")

        if not url.lower().startswith(("http://", "https://", "mailto:")):
            prefix = prefixes.get(label)
            if not prefix:
                # Raw, official-English, Amazon and ebookjapan values should be
                # complete URLs. Never turn an unknown relative value into a
                # link on the local preview or GitHub Pages domain.
                continue
            url = prefix + url.lstrip("/")

        # Do not preserve localhost links from an older generated cache.
        if re.match(r"^https?://(?:127\.0\.0\.1|localhost)(?::\d+)?/", url, re.I):
            continue
        result[label] = url
    return result

def _merged_tags(mangadex_tags: list[Any], mapping: dict[str, Any]) -> list[str]:
    hidden = {str(tag).strip().casefold() for tag in (mapping.get("hidden_tags") or []) if str(tag).strip()}
    followed = [str(tag).strip() for tag in mangadex_tags if str(tag).strip() and str(tag).strip().casefold() not in hidden]
    return _clean_tags(followed + list(mapping.get("custom_tags") or []))


def _merge_record(local: dict[str, Any], mapping: dict[str, Any]) -> dict[str, Any]:
    manga_id = mapping.get("mangadex_id", "") or local.get("mangadex_id", "")
    md = load_cached_metadata(manga_id) if manga_id else {}
    latest = local.get("latest_chapter") or {}
    cover_rel = "assets/placeholder-cover.svg"
    cover_file = COVERS_DIR / f"{manga_id}.jpg" if manga_id else None
    if cover_file and cover_file.exists():
        cover_rel = f"assets/covers/{manga_id}.jpg"
    elif local.get("cover"):
        cover_rel = local["cover"]

    title = mapping.get("title_override") or md.get("title") or local.get("title") or "Untitled"
    description = mapping.get("description_override") or md.get("description") or local.get("description") or "No description is available."
    authors = _clean_tags(md.get("authors") or ([local.get("author")] if local.get("author") else []))
    artists = _clean_tags(md.get("artists") or ([local.get("artist")] if local.get("artist") else []))
    tags = _merged_tags(md.get("tags") or [], mapping)

    detected_update = max(int(latest.get("last_updated") or 0), int(local.get("last_updated") or 0))
    if not detected_update:
        detected_update = int(local.get("source_mtime") or 0)

    cubari_url = str(local.get("cubari_url") or "").strip()
    chapters: list[dict[str, Any]] = []
    for chapter in local.get("chapters") or []:
        number = str(chapter.get("number") or "").strip()
        chapter_updated = int(chapter.get("last_updated") or 0)
        album_id = str(chapter.get("imgchest_id") or "").strip()
        chapter_url = _chapter_cubari_url(cubari_url, number)
        direct_pages = chapter.get("pages") or []
        # Counts are optional metadata only, never a condition for reading.
        count = len(direct_pages) if direct_pages else load_cubari_count(album_id, chapter_updated)
        chapters.append({
            "number": number,
            "title": str(chapter.get("title") or "").strip(),
            "volume": str(chapter.get("volume") or "").strip(),
            "last_updated": chapter_updated,
            "last_updated_display": _display_date(chapter_updated),
            "cubari_url": chapter_url,
            "page_count": count,
        })

    return {
        "id": local["id"],
        "slug": local.get("slug") or local["id"],
        "title": title,
        "original_title": md.get("original_title", ""),
        "alt_titles": md.get("alt_titles", []),
        "description": description,
        "authors": authors,
        "artists": artists,
        "status": md.get("status", ""),
        "year": md.get("year"),
        "demographic": md.get("publication_demographic", ""),
        "content_rating": md.get("content_rating", ""),
        "tags": tags,
        "external_links": _normalize_external_links(md.get("links", {})),
        "cover": cover_rel,
        "cubari_url": cubari_url,
        "chapters": chapters,
        "mangadex_url": md.get("mangadex_url", "") or (f"https://mangadex.org/title/{manga_id}" if manga_id else ""),
        "chapter_count": local.get("chapter_count", 0),
        "latest_chapter": latest,
        "latest_chapter_number": latest.get("number", ""),
        "latest_chapter_title": latest.get("title", ""),
        "last_updated": detected_update,
        "last_updated_display": _display_date(detected_update),
        "mangadex_refreshed_at": md.get("refreshed_at", 0),
    }


def _public_site_config(site_config: dict[str, Any]) -> dict[str, Any]:
    mode = str(site_config.get("tag_match_mode") or "any").lower()
    if mode not in {"any", "all"}:
        mode = "any"
    try:
        max_card_tags = max(0, min(12, int(site_config.get("max_card_tags", 3))))
    except (TypeError, ValueError):
        max_card_tags = 3
    try:
        chapter_preview_rows = max(1, min(6, int(site_config.get("chapter_preview_rows", 2))))
    except (TypeError, ValueError):
        chapter_preview_rows = 2
    try:
        chapter_group_size = max(25, min(500, int(site_config.get("chapter_group_size", 100))))
    except (TypeError, ValueError):
        chapter_group_size = 100
    return {
        "eyebrow": str(site_config.get("eyebrow") or "CUBARI RELEASE CATALOGUE"),
        "name": str(site_config.get("name") or "Cubari Manga Library"),
        "browser_title": str(site_config.get("browser_title") or site_config.get("name") or "Cubari Manga Library"),
        "subtitle": str(site_config.get("subtitle") or ""),
        "footer": str(site_config.get("footer") or ""),
        "search_placeholder": str(site_config.get("search_placeholder") or "Search titles, tags, authors…"),
        "tags_heading": str(site_config.get("tags_heading") or "Browse by tag"),
        "read_mangadex_label": str(site_config.get("read_mangadex_label") or "Read on MangaDex"),
        "latest_release_label": str(site_config.get("latest_release_label") or "Latest Cubari release"),
        "last_update_label": str(site_config.get("last_update_label") or "Last Cubari update"),
        "accent": str(site_config.get("accent") or "#ff6740"),
        "show_tag_filters": bool(site_config.get("show_tag_filters", True)),
        "tag_match_mode": mode,
        "max_card_tags": max_card_tags,
        "chapter_preview_rows": chapter_preview_rows,
        "chapter_group_size": chapter_group_size,
    }


def generate_site(config: dict[str, Any], library: dict[str, Any], mappings: dict[str, Any]) -> dict[str, Any]:
    if GENERATED_DIR.exists():
        shutil.rmtree(GENERATED_DIR)
    (GENERATED_DIR / "data" / "titles").mkdir(parents=True, exist_ok=True)
    (GENERATED_DIR / "assets" / "covers").mkdir(parents=True, exist_ok=True)

    raw_site_config = config.get("site") or {}
    site = _public_site_config(raw_site_config)
    show_unmapped = bool(raw_site_config.get("show_unmapped", True))
    records: list[dict[str, Any]] = []
    custom_count = 0
    (GENERATED_DIR / "data" / "cubari-reader").mkdir(parents=True, exist_ok=True)
    for local in library.get("titles") or []:
        mapping = mappings.get(local.get("id"), {})
        effective_md_id = mapping.get("mangadex_id") or local.get("mangadex_id")
        if mapping.get("excluded"):
            continue
        if not show_unmapped and not effective_md_id:
            continue
        record = _merge_record(local, mapping)
        originals = {str(ch.get("number")):ch for ch in local.get("chapters", [])}
        reader_chapters = {}
        for ch in record["chapters"]:
            pages = load_reader_pages(originals.get(ch["number"], {})) if raw_site_config.get("modified_cubari_enabled") is True else []
            # Preserve non-numeric chapter keys with the existing full embedded reader.
            ready = bool(pages and ch["cubari_url"] and re.fullmatch(r"\d+(?:\.\d+)?", ch["number"]))
            ch["custom_reader"] = ready
            if ready:
                ch["page_count"] = len(pages)
                custom_count += 1
            if re.fullmatch(r"\d+(?:\.\d+)?", ch["number"]) and ch["cubari_url"]:
                reader_chapters[ch["number"]] = {"title":ch["title"], "volume":ch["volume"] if re.fullmatch(r"\d+(?:\.\d+)?", ch["volume"]) else "1", "groups":{"1":pages if ready else []}, "publisher_fallback":not ready}
        if any(not ch["publisher_fallback"] for ch in reader_chapters.values()):
            save_json(GENERATED_DIR / "data" / "cubari-reader" / f"{record['id']}.json", {"slug":record["id"],"title":record["title"],"groups":{"1":"Release"},"chapters":reader_chapters})
        records.append(record)
        save_json(GENERATED_DIR / "data" / "titles" / f"{record['id']}.json", record)
        if record["cover"].startswith("assets/covers/"):
            source = COVERS_DIR / f"{effective_md_id}.jpg"
            if source.exists():
                shutil.copy2(source, GENERATED_DIR / record["cover"])

    records.sort(key=lambda item: (-item["last_updated"], item["title"].casefold()))
    tag_counts: Counter[str] = Counter()
    tag_display: dict[str, str] = {}
    for record in records:
        for tag in record.get("tags") or []:
            key = tag.casefold()
            tag_counts[key] += 1
            tag_display.setdefault(key, tag)
    tags = [
        {"name": tag_display[key], "count": count}
        for key, count in sorted(tag_counts.items(), key=lambda pair: (-pair[1], tag_display[pair[0]].casefold()))
    ]

    catalog = {
        "generated_at": int(datetime.now(tz=timezone.utc).timestamp()),
        "site": site,
        "tags": tags,
        "titles": [
            {
                "id": item["id"],
                "title": item["title"],
                "original_title": item["original_title"],
                "alt_titles": item["alt_titles"],
                "authors": item["authors"],
                "artists": item["artists"],
                "cover": item["cover"],
                "tags": item["tags"],
                "status": item["status"],
                "chapter_count": item["chapter_count"],
                "latest_chapter_number": item["latest_chapter_number"],
                "last_updated": item["last_updated"],
                "last_updated_display": item["last_updated_display"],
            }
            for item in records
        ],
    }
    save_json(GENERATED_DIR / "data" / "catalog.json", catalog)
    save_json(GENERATED_DIR / "data" / "site.json", site)
    _write_static_files(site, catalog["generated_at"])
    shutil.copytree(Path(__file__).resolve().parent / "cubari_frontend", GENERATED_DIR / "cubari", dirs_exist_ok=True)

    (GENERATED_DIR / ".nojekyll").write_text("", encoding="utf-8")
    files = sorted(path.relative_to(GENERATED_DIR).as_posix() for path in GENERATED_DIR.rglob("*") if path.is_file())
    save_json(GENERATED_DIR / ".cubari-site-manifest.json", {"files": files + [".cubari-site-manifest.json"]})
    embedded_chapters = sum(bool(ch["cubari_url"]) for record in records for ch in record["chapters"])
    warnings = [{"title": record["title"], "chapter": ch["number"]}
                for record in records for ch in record["chapters"] if not ch["cubari_url"]]
    return {
        "reader_warnings": warnings,
        "title_count": len(records),
        "tag_count": len(tags),
        "embedded_reader_chapters": embedded_chapters - custom_count,
        "custom_cubari_chapters": custom_count,
        "file_count": len([path for path in GENERATED_DIR.rglob("*") if path.is_file()]),
        "generated_at": catalog["generated_at"],
        "preview_url": "/site/",
        "directory": str(GENERATED_DIR),
    }


def _write_static_files(site: dict[str, Any], build_id: int) -> None:
    name = html.escape(site["name"])
    browser_title = html.escape(site["browser_title"])
    subtitle = _render_safe_markdown(site["subtitle"])
    eyebrow = html.escape(site["eyebrow"])
    footer = html.escape(site["footer"])
    search_placeholder = html.escape(site["search_placeholder"], quote=True)
    tags_heading = html.escape(site["tags_heading"])
    accent = html.escape(site["accent"], quote=True)
    tag_filter_hidden = "" if site["show_tag_filters"] else " hidden"

    index_html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="dark">
  <title>{browser_title}</title>
  <link rel="stylesheet" href="assets/site.css?v={build_id}">
</head>
<body style="--accent:{accent}">
  <header class="hero">
    <div class="hero-inner">
      <p class="eyebrow">{eyebrow}</p>
      <h1>{name}</h1>
      <p class="hero-introduction">{subtitle}</p>
      <div class="toolbar">
        <input id="search" type="search" placeholder="{search_placeholder}" autocomplete="off">
        <select id="sort" aria-label="Sort titles">
          <option value="recent">Recently updated</option>
          <option value="title">Title A–Z</option>
          <option value="chapters">Most Cubari chapters</option>
        </select>
      </div>
    </div>
  </header>
  <main>
    <section id="tagPanel" class="tag-panel"{tag_filter_hidden}>
      <div class="tag-panel-heading">
        <div><p class="eyebrow small-eyebrow">FILTER</p><h2>{tags_heading}</h2></div>
        <button id="clearTags" class="clear-filter" type="button" hidden>Clear tags</button>
      </div>
      <div id="tagFilters" class="tag-filters" aria-label="Tag filters"></div>
      <p id="tagEmpty" class="tag-empty" hidden>No tags are cached yet. Return to Cubari Site Publisher and run “Refresh All MangaDex Data,” then regenerate the preview.</p>
    </section>
    <div id="summary" class="summary"></div>
    <section id="grid" class="grid" aria-live="polite"></section>
    <p id="empty" class="empty" hidden>No matching titles.</p>
  </main>
  <footer>{footer} · <a href="cubari/credits.html">Cubari reader credits and source</a></footer>
  <script src="assets/catalog.js?v={build_id}"></script>
</body>
</html>
"""

    title_html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="dark">
  <title>{browser_title}</title>
  <link rel="stylesheet" href="assets/site.css?v={build_id}">
</head>
<body style="--accent:{accent}">
  <main id="titlePage" class="title-page"><p class="loading">Loading title…</p></main>
  <script src="assets/title.js?v={build_id}"></script>
</body>
</html>
"""

    css = r"""
:root{font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#f3f4f6;background:#111319;--accent:#ff6740;--panel:#1b1e27;--muted:#a6adbb;--line:#303542}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 10% 0,#25202b 0,transparent 28rem),#111319;color:#f4f5f7}a{color:inherit}.hero{border-bottom:1px solid var(--line);background:linear-gradient(180deg,rgba(255,255,255,.035),transparent)}.hero-inner,main{width:min(1220px,calc(100% - 32px));margin:auto}.hero-inner{padding:60px 0 34px}.eyebrow{font-size:.75rem;letter-spacing:.16em;color:var(--accent);font-weight:800;margin:0 0 10px}.small-eyebrow{font-size:.65rem;margin-bottom:5px}.hero h1{font-size:clamp(2rem,5vw,4.4rem);line-height:.98;margin:0;max-width:900px}.hero p:not(.eyebrow){color:var(--muted);max-width:760px;font-size:1.05rem}.hero-introduction a{color:#fff;text-decoration-color:var(--accent);text-underline-offset:3px}.hero-introduction a:hover{color:var(--accent)}.hero-introduction strong{color:#fff}.toolbar{display:grid;grid-template-columns:minmax(0,1fr) 220px;gap:12px;margin-top:28px}.toolbar input,.toolbar select{width:100%;border:1px solid var(--line);background:#171a22;color:#fff;border-radius:12px;padding:14px 16px;font:inherit;outline:none}.toolbar input:focus,.toolbar select:focus{border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 22%,transparent)}main{padding:28px 0 60px}.tag-panel{border:1px solid var(--line);background:color-mix(in srgb,var(--panel) 88%,transparent);border-radius:16px;padding:18px;margin-bottom:20px}.tag-panel-heading{display:flex;align-items:end;justify-content:space-between;gap:16px;margin-bottom:13px}.tag-panel h2{font-size:1rem;margin:0}.tag-filters{display:flex;flex-wrap:wrap;gap:8px}.tag-empty{margin:8px 0 0;color:var(--muted);font-size:.85rem}.tag-filter,.card-tag,.clear-filter{font:inherit;cursor:pointer}.tag-filter{border:1px solid var(--line);background:#242935;color:#d8dce4;border-radius:999px;padding:7px 11px;font-size:.78rem;transition:.15s border-color,.15s background,.15s color}.tag-filter:hover{border-color:var(--accent)}.tag-filter.active{background:var(--accent);border-color:var(--accent);color:#111319;font-weight:800}.tag-filter .count{opacity:.7;margin-left:4px}.clear-filter{border:0;background:transparent;color:var(--accent);padding:5px;font-weight:700}.summary{color:var(--muted);margin-bottom:18px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(205px,1fr));gap:20px}.card{display:flex;flex-direction:column;background:var(--panel);border:1px solid var(--line);border-radius:16px;overflow:hidden;transition:.18s transform,.18s border-color,.18s box-shadow}.card:hover{transform:translateY(-4px);border-color:color-mix(in srgb,var(--accent) 65%,var(--line));box-shadow:0 15px 32px rgba(0,0,0,.28)}.cover-link{display:block}.cover-wrap{aspect-ratio:2/3;background:#262a35;overflow:hidden}.cover-wrap img{width:100%;height:100%;object-fit:cover;display:block}.card-body{padding:14px 14px 16px}.title-link{text-decoration:none}.card h2{font-size:1rem;line-height:1.3;margin:0 0 10px}.meta{color:var(--muted);font-size:.82rem;display:grid;gap:4px}.badge-row{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}.badge,.card-tag{font-size:.68rem;padding:4px 7px;border-radius:999px;background:#292e39;color:#cdd2dc;border:1px solid transparent;text-decoration:none}.card-tag:hover,.badge[href]:hover{border-color:var(--accent);color:#fff}.empty{padding:80px 0;text-align:center;color:var(--muted)}footer{border-top:1px solid var(--line);color:var(--muted);padding:24px;text-align:center;font-size:.82rem;white-space:pre-line}.title-page{padding-top:38px}.back{display:inline-flex;align-items:center;gap:8px;color:var(--muted);text-decoration:none;margin-bottom:24px}.title-hero{display:grid;grid-template-columns:minmax(210px,300px) minmax(0,1fr);gap:36px;align-items:start}.title-cover{width:100%;aspect-ratio:2/3;object-fit:cover;border-radius:18px;border:1px solid var(--line);box-shadow:0 24px 45px rgba(0,0,0,.3)}.kicker{color:var(--accent);font-weight:800;font-size:.8rem;letter-spacing:.12em}.title-info h1{font-size:clamp(2rem,5vw,4rem);line-height:1.03;margin:6px 0 8px}.original-title{color:var(--muted);font-size:1.1rem;margin:0 0 18px}.facts{display:flex;flex-wrap:wrap;gap:8px;margin:16px 0}.fact{border:1px solid var(--line);background:var(--panel);border-radius:999px;padding:7px 11px;color:#d5d8df;font-size:.82rem}.buttons{display:flex;flex-wrap:wrap;gap:12px;margin:26px 0}.button{display:inline-flex;justify-content:center;align-items:center;min-height:46px;padding:0 18px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid var(--line);background:#242935}.button.primary{background:var(--accent);border-color:var(--accent);color:#111319}.button.disabled{opacity:.45;pointer-events:none}.section{margin-top:38px;padding-top:28px;border-top:1px solid var(--line)}.section h2{font-size:1.2rem;margin-top:0}.section p{color:#d7dae0;line-height:1.72;white-space:pre-wrap}.link-list{display:flex;flex-wrap:wrap;gap:10px}.link-list a{color:#e9ebef;border:1px solid var(--line);background:var(--panel);padding:9px 12px;border-radius:10px;text-decoration:none}.alt-titles{color:var(--muted);line-height:1.55}.chapter-list{display:grid;gap:10px}.chapter-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:18px;align-items:center;padding:13px 14px;border:1px solid var(--line);background:var(--panel);border-radius:12px}.chapter-main{min-width:0}.chapter-name{font-weight:800;line-height:1.3}.chapter-sub{color:var(--muted);font-size:.78rem;margin-top:4px}.chapter-read{white-space:nowrap;min-height:38px;padding:0 13px;font-size:.8rem}.loading{color:var(--muted);padding:60px 0}@media(max-width:720px){.toolbar{grid-template-columns:1fr}.chapter-row{grid-template-columns:1fr}.chapter-read{width:100%}.title-hero{grid-template-columns:1fr}.title-cover{max-width:270px}.hero-inner{padding-top:38px}.grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.card-body{padding:11px}.card h2{font-size:.9rem}.tag-panel-heading{align-items:start}}@media(max-width:430px){.hero-inner,main{width:min(100% - 20px,1220px)}}
.chapter-row{color:inherit;text-decoration:none;cursor:pointer;transition:border-color .16s ease,background .16s ease,transform .16s ease}.chapter-row:hover,.chapter-row:focus-visible{border-color:color-mix(in srgb,var(--accent) 70%,var(--line));background:color-mix(in srgb,var(--accent) 8%,var(--panel));transform:translateY(-1px);outline:none}.chapter-row.unavailable{cursor:default;opacity:.55}
/* Title metadata and scalable chapter browser */
.title-details{display:grid;grid-template-columns:minmax(0,1fr) minmax(260px,.65fr);gap:28px;margin-top:38px;padding-top:30px;border-top:1px solid var(--line)}
.title-detail{min-width:0}.title-detail.description-detail{grid-column:1/-1}.title-detail h2{font-size:1.2rem;margin:0 0 16px}.title-detail p{color:#d7dae0;line-height:1.72;white-space:pre-wrap;margin:0}.title-detail .link-list{align-items:flex-start}.releases-section{margin-top:38px}.releases-heading{display:flex;align-items:flex-end;justify-content:space-between;gap:16px}.releases-heading h2{display:flex;align-items:center;gap:9px;margin-bottom:6px}.chapter-total{display:inline-flex;align-items:center;justify-content:center;min-width:28px;height:24px;padding:0 8px;border-radius:999px;background:color-mix(in srgb,var(--accent) 18%,var(--panel));color:var(--accent);font-size:.72rem}.section-note,.chapter-summary{color:var(--muted)!important;font-size:.88rem;line-height:1.5!important;margin:0}.chapter-tools{display:grid;grid-template-columns:minmax(0,1fr) 150px;gap:12px;margin:18px 0 14px}.chapter-tools input,.chapter-tools select{width:100%;border:1px solid var(--line);background:#171a22;color:#fff;border-radius:11px;padding:11px 13px;font:inherit;outline:none}.chapter-tools input:focus,.chapter-tools select:focus{border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 20%,transparent)}.chapter-jump-wrap{display:flex;align-items:flex-start;gap:12px;margin:14px 0 16px;padding:13px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}.chapter-jump-label{flex:none;padding-top:8px;color:var(--muted);font-size:.68rem;letter-spacing:.16em;font-weight:800}.chapter-jump{display:flex;flex-wrap:wrap;gap:8px;min-width:0}.chapter-range{border:1px solid var(--line);background:#20242e;color:#cdd3de;border-radius:9px;padding:7px 10px;font:inherit;font-size:.76rem;cursor:pointer}.chapter-range:hover{border-color:var(--accent)}.chapter-range.active{border-color:var(--accent);background:color-mix(in srgb,var(--accent) 16%,#20242e);color:#fff}.chapter-summary{margin:14px 0 10px}.chapter-list{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.chapter-row{position:relative;min-height:62px;padding:10px 12px;text-decoration:none;color:inherit;transition:.15s border-color,.15s background,.15s transform}.chapter-row:hover{border-color:color-mix(in srgb,var(--accent) 70%,var(--line));background:color-mix(in srgb,var(--accent) 7%,var(--panel));transform:translateY(-1px)}.chapter-row:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.chapter-main{padding-right:6px}.chapter-name{padding-right:8px}.chapter-sub{display:flex;flex-wrap:wrap;align-items:center;gap:4px 6px}.chapter-views{white-space:nowrap;color:#8791a8}.chapter-arrow{align-self:center;color:var(--accent);font-size:1.55rem;line-height:1}.chapter-row.unavailable{opacity:.62}.chapter-toggle-wrap{display:flex;justify-content:center;margin-top:24px}.chapter-toggle{min-width:250px;border:1px solid var(--line);background:#20242e;color:#dbe0e8;border-radius:12px;padding:12px 20px;font:inherit;font-weight:750;cursor:pointer}.chapter-toggle:hover{border-color:var(--accent);color:#fff}.chapter-empty{color:var(--muted);text-align:center;padding:28px 0}.chapter-preview .chapter-row:nth-child(n+13){display:none}
@media(max-width:720px){.title-details{grid-template-columns:1fr;gap:24px}.title-detail.description-detail{grid-column:auto}.chapter-tools{grid-template-columns:1fr}.chapter-list{grid-template-columns:1fr}.chapter-jump-wrap{display:block}.chapter-jump-label{display:block;padding:0 0 9px}.chapter-row{min-height:58px}.chapter-toggle{width:100%}}

"""

    catalog_js = r"""
const grid=document.querySelector('#grid');const search=document.querySelector('#search');const sort=document.querySelector('#sort');const summary=document.querySelector('#summary');const empty=document.querySelector('#empty');const tagFilters=document.querySelector('#tagFilters');const clearTags=document.querySelector('#clearTags');const tagPanel=document.querySelector('#tagPanel');const tagEmpty=document.querySelector('#tagEmpty');let titles=[];let site={};let availableTags=[];const selectedTags=new Set();
const esc=(v)=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));const key=v=>String(v??'').trim().toLocaleLowerCase();
function syncUrl(){const url=new URL(location.href);url.searchParams.delete('tag');[...selectedTags].forEach(tag=>url.searchParams.append('tag',tag));history.replaceState(null,'',url)}
function toggleTag(tag){const normalized=key(tag);const current=[...selectedTags].find(item=>key(item)===normalized);if(current)selectedTags.delete(current);else selectedTags.add(tag);syncUrl();renderTags();render();}
function renderTags(){if(!site.show_tag_filters){tagPanel.hidden=true;return}tagPanel.hidden=false;tagEmpty.hidden=availableTags.length!==0;const allButton=`<button type="button" class="tag-filter ${selectedTags.size===0?'active':''}" data-all="1">All <span class="count">${titles.length}</span></button>`;tagFilters.innerHTML=allButton+availableTags.map(item=>{const active=[...selectedTags].some(tag=>key(tag)===key(item.name));return `<button type="button" class="tag-filter ${active?'active':''}" data-tag="${esc(item.name)}">${esc(item.name)} <span class="count">${item.count}</span></button>`}).join('');tagFilters.querySelector('[data-all]')?.addEventListener('click',()=>{selectedTags.clear();syncUrl();renderTags();render()});tagFilters.querySelectorAll('[data-tag]').forEach(button=>button.addEventListener('click',()=>toggleTag(button.dataset.tag)));clearTags.hidden=selectedTags.size===0;}
function matchesTags(title){if(selectedTags.size===0)return true;const titleTags=new Set((title.tags||[]).map(key));const selected=[...selectedTags].map(key);return site.tag_match_mode==='all'?selected.every(tag=>titleTags.has(tag)):selected.some(tag=>titleTags.has(tag));}
function render(){const q=key(search.value);let items=titles.filter(t=>{const haystack=[t.title,t.original_title,...(t.alt_titles||[]),...(t.authors||[]),...(t.artists||[]),...(t.tags||[])].join(' ').toLocaleLowerCase();return (!q||haystack.includes(q))&&matchesTags(t)});if(sort.value==='title')items.sort((a,b)=>a.title.localeCompare(b.title));else if(sort.value==='chapters')items.sort((a,b)=>(b.chapter_count||0)-(a.chapter_count||0)||a.title.localeCompare(b.title));else items.sort((a,b)=>(b.last_updated||0)-(a.last_updated||0)||a.title.localeCompare(b.title));const filterText=selectedTags.size?` • ${site.tag_match_mode==='all'?'matching all':'matching any'}: ${[...selectedTags].join(', ')}`:'';summary.textContent=`${items.length} of ${titles.length} titles${filterText}`;empty.hidden=items.length!==0;const maxTags=Number(site.max_card_tags??3);grid.innerHTML=items.map(t=>`<article class="card"><a class="cover-link" href="title.html?id=${encodeURIComponent(t.id)}"><div class="cover-wrap"><img loading="lazy" src="${esc(t.cover)}" alt=""></div></a><div class="card-body"><a class="title-link" href="title.html?id=${encodeURIComponent(t.id)}"><h2>${esc(t.title)}</h2></a><div class="meta"><span>${t.latest_chapter_number?`${esc(site.latest_release_label||'Latest Cubari release')}: ${esc(t.latest_chapter_number)}`:'No chapter number detected'}</span><span>${esc(site.last_update_label||'Last Cubari update')}: ${esc(t.last_updated_display)}</span></div><div class="badge-row">${(maxTags===0?[]:(t.tags||[]).slice(0,maxTags)).map(tag=>`<button type="button" class="card-tag" data-tag="${esc(tag)}">${esc(tag)}</button>`).join('')}</div></div></article>`).join('');grid.querySelectorAll('.card-tag').forEach(button=>button.addEventListener('click',()=>{toggleTag(button.dataset.tag);tagPanel.scrollIntoView({behavior:'smooth',block:'start'})}));}
clearTags.addEventListener('click',()=>{selectedTags.clear();syncUrl();renderTags();render()});
fetch('data/catalog.json',{cache:'no-store'}).then(r=>r.json()).then(data=>{titles=data.titles||[];site=data.site||{};availableTags=data.tags||[];document.documentElement.style.setProperty('--accent',site.accent||'#ff6740');const params=new URLSearchParams(location.search);params.getAll('tag').forEach(tag=>{const found=availableTags.find(item=>key(item.name)===key(tag));if(found)selectedTags.add(found.name)});renderTags();render()}).catch(e=>{summary.textContent='Could not load catalog.json';console.error(e)});search.addEventListener('input',render);sort.addEventListener('change',render);
"""

    title_js = r"""
const root=document.querySelector('#titlePage');const esc=(v)=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));const id=new URLSearchParams(location.search).get('id');
function button(label,url,primary=false){return url?`<a class="button ${primary?'primary':''}" href="${esc(url)}" target="_blank" rel="noopener">${esc(label)}</a>`:`<span class="button disabled">${esc(label)}</span>`}
function chapterLabel(number){const value=String(number||'').trim();return value?`Chapter ${value}`:'Chapter'}
function numberValue(chapter){const match=String(chapter?.number??'').match(/-?\d+(?:\.\d+)?/);return match?Number(match[0]):Number.NaN}
function compareNewest(a,b){const av=numberValue(a),bv=numberValue(b);if(Number.isFinite(av)&&Number.isFinite(bv)&&av!==bv)return bv-av;const ad=Number(a.last_updated||0),bd=Number(b.last_updated||0);if(ad!==bd)return bd-ad;return String(b.number||'').localeCompare(String(a.number||''),undefined,{numeric:true,sensitivity:'base'})}
function formatNumber(value){return new Intl.NumberFormat().format(Number(value)||0)}
function chapterSearchText(ch){return [ch.number,ch.title,ch.volume,ch.last_updated_display].filter(Boolean).join(' ').toLocaleLowerCase()}
function rangeLabel(items){if(!items.length)return 'Other';const first=String(items[0].number||'').trim()||'?';const last=String(items[items.length-1].number||'').trim()||'?';return first===last?first:`${first}–${last}`}
function chapterCard(ch,t,site){const label=`${chapterLabel(ch.number)}${ch.title?` — ${ch.title}`:''}`;const details=[];if(ch.volume)details.push(`Volume ${esc(ch.volume)}`);if(ch.last_updated)details.push(esc(ch.last_updated_display));if(ch.page_count)details.push(`<span title="Cached page count from Cubari or original chapter JSON">${formatNumber(ch.page_count)} pages</span>`);const detailHtml=details.length?`<div class="chapter-sub">${details.join(' <span aria-hidden="true">•</span> ')}</div>`:'';const readerUrl=`reader.html?id=${encodeURIComponent(t.id)}&chapter=${encodeURIComponent(ch.number)}`;if(ch.cubari_url)return `<a class="chapter-row" href="${readerUrl}" title="Read in embedded Cubari"><div class="chapter-main"><div class="chapter-name">${esc(label)}</div>${detailHtml}</div><span class="chapter-arrow" aria-hidden="true">›</span></a>`;return `<article class="chapter-row unavailable"><div class="chapter-main"><div class="chapter-name">${esc(label)}</div>${detailHtml}<div class="chapter-sub">No Cubari link available</div></div></article>`}
Promise.all([fetch(`data/titles/${encodeURIComponent(id)}.json`,{cache:'no-store'}).then(r=>{if(!r.ok)throw new Error('Title not found');return r.json()}),fetch('data/site.json',{cache:'no-store'}).then(r=>r.json())]).then(([t,site])=>{
  document.title=`${t.title} | ${site.browser_title||site.name||''}`;document.documentElement.style.setProperty('--accent',site.accent||'#ff6740');
  const facts=[t.status,t.year,t.demographic,t.content_rating,t.chapter_count?`${formatNumber(t.chapter_count)} Cubari chapters`:null].filter(Boolean);
  const chapters=[...(t.chapters||[])].sort(compareNewest);const previewRows=Math.max(1,Math.min(6,Number(site.chapter_preview_rows)||2));const previewCount=previewRows*2;const groupSize=Math.max(25,Math.min(500,Number(site.chapter_group_size)||100));const groups=[];for(let i=0;i<chapters.length;i+=groupSize){const items=chapters.slice(i,i+groupSize);groups.push({items,label:rangeLabel(items)})}
  const detailSections=`<section class="title-details"><article class="title-detail description-detail"><h2>Description</h2><p>${esc(t.description)}</p></article>${(t.alt_titles||[]).length?`<article class="title-detail"><h2>Alternative titles</h2><p class="alt-titles">${esc(t.alt_titles.join(' • '))}</p></article>`:''}${Object.keys(t.external_links||{}).length?`<article class="title-detail"><h2>External links</h2><div class="link-list">${Object.entries(t.external_links).map(([k,v])=>`<a href="${esc(v)}" target="_blank" rel="noopener">${esc(k)}</a>`).join('')}</div></article>`:''}</section>`;
  const chapterSection=chapters.length?`<section class="section releases-section"><div class="releases-heading"><div><h2>Cubari releases <span class="chapter-total">${formatNumber(chapters.length)}</span></h2><p class="section-note">Select a chapter to read it in the original Cubari reader, embedded here.</p></div></div><div id="chapterTools" class="chapter-tools" hidden><input id="chapterSearch" type="search" placeholder="Search chapters…" autocomplete="off" aria-label="Search chapters"><select id="chapterSort" aria-label="Sort chapters"><option value="newest">Newest</option><option value="oldest">Oldest</option></select></div><div id="chapterJumpWrap" class="chapter-jump-wrap" hidden><span class="chapter-jump-label">JUMP TO</span><div id="chapterJump" class="chapter-jump"></div></div><p id="chapterSummary" class="chapter-summary"></p><div id="chapterList" class="chapter-list chapter-preview"></div><p id="chapterEmpty" class="chapter-empty" hidden>No matching chapters.</p>${chapters.length>previewCount?`<div class="chapter-toggle-wrap"><button id="chapterToggle" class="chapter-toggle" type="button">Show all ${formatNumber(chapters.length)} chapters <span aria-hidden="true">⌄</span></button></div>`:''}</section>`:'';
  root.innerHTML=`<a class="back" href="index.html">← Back to catalogue</a><div class="title-hero"><img class="title-cover" src="${esc(t.cover)}" alt=""><article class="title-info"><div class="kicker">MANGA TITLE</div><h1>${esc(t.title)}</h1>${t.original_title&&t.original_title!==t.title?`<p class="original-title">${esc(t.original_title)}</p>`:''}<div class="facts">${facts.map(x=>`<span class="fact">${esc(x)}</span>`).join('')}</div><p class="alt-titles">${(t.authors||[]).length?`Author: ${esc(t.authors.join(', '))}<br>`:''}${(t.artists||[]).length?`Artist: ${esc(t.artists.join(', '))}<br>`:''}${t.latest_chapter_number?`${esc(site.latest_release_label||'Latest Cubari release')}: ${esc(t.latest_chapter_number)}<br>`:''}${esc(site.last_update_label||'Last Cubari update')}: ${esc(t.last_updated_display)}</p><div class="buttons">${button(site.read_mangadex_label||'Read on MangaDex',t.mangadex_url,true)}</div><div class="badge-row">${(t.tags||[]).map(tag=>`<a class="badge" href="index.html?tag=${encodeURIComponent(tag)}">${esc(tag)}</a>`).join('')}</div></article></div>${detailSections}${chapterSection}`;
  if(!chapters.length)return;
  let expanded=false;let selectedGroup=0;let sortOrder='newest';let query='';const list=document.querySelector('#chapterList');const tools=document.querySelector('#chapterTools');const jumpWrap=document.querySelector('#chapterJumpWrap');const jump=document.querySelector('#chapterJump');const summary=document.querySelector('#chapterSummary');const empty=document.querySelector('#chapterEmpty');const toggle=document.querySelector('#chapterToggle');const search=document.querySelector('#chapterSearch');const sort=document.querySelector('#chapterSort');
  function renderJump(){jump.innerHTML=groups.map((group,index)=>`<button type="button" class="chapter-range ${index===selectedGroup?'active':''}" data-group="${index}">${esc(group.label)}</button>`).join('');jump.querySelectorAll('[data-group]').forEach(btn=>btn.addEventListener('click',()=>{selectedGroup=Number(btn.dataset.group)||0;renderChapters();document.querySelector('.releases-section')?.scrollIntoView({behavior:'smooth',block:'start'})}))}
  function renderChapters(){const normalized=query.trim().toLocaleLowerCase();let items;let label;if(!expanded){items=chapters.slice(0,previewCount);label=`Latest ${items.length} of ${formatNumber(chapters.length)} chapters`}else if(normalized){items=chapters.filter(ch=>chapterSearchText(ch).includes(normalized));label=`${formatNumber(items.length)} matching chapters`}else if(groups.length>1){items=[...groups[selectedGroup].items];label=`${formatNumber(items.length)} chapters in ${groups[selectedGroup].label}`}else{items=[...chapters];label=`All ${formatNumber(items.length)} chapters`}if(sortOrder==='oldest')items.reverse();list.classList.toggle('chapter-preview',!expanded);list.innerHTML=items.map(ch=>chapterCard(ch,t,site)).join('');empty.hidden=items.length!==0;summary.textContent=label;tools.hidden=!expanded;jumpWrap.hidden=!expanded||Boolean(normalized)||groups.length<=1;if(!jumpWrap.hidden)renderJump();if(toggle){toggle.innerHTML=expanded?`Show recent chapters <span aria-hidden="true">⌃</span>`:`Show all ${formatNumber(chapters.length)} chapters <span aria-hidden="true">⌄</span>`}}
  toggle?.addEventListener('click',()=>{expanded=!expanded;if(!expanded){query='';if(search)search.value='';selectedGroup=0;sortOrder='newest';if(sort)sort.value='newest'}renderChapters()});search?.addEventListener('input',()=>{query=search.value;renderChapters()});sort?.addEventListener('change',()=>{sortOrder=sort.value==='oldest'?'oldest':'newest';if(!query&&groups.length>1)selectedGroup=sortOrder==='oldest'?groups.length-1:0;renderChapters()});renderChapters();
}).catch(e=>{root.innerHTML=`<a class="back" href="index.html">← Back</a><p class="loading">${esc(e.message)}</p>`});
"""


    placeholder = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 768"><rect width="512" height="768" fill="#252a34"/><path d="M120 250h272v268H120z" fill="#303643"/><circle cx="256" cy="348" r="70" fill="#454d5e"/><path d="M158 494c18-70 63-105 98-105s80 35 98 105" fill="#454d5e"/><text x="256" y="610" text-anchor="middle" fill="#9ba3b3" font-family="sans-serif" font-size="28">No cover</text></svg>"""

    embedded_html = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="dark"><title>Reader | {browser_title}</title>
<link rel="stylesheet" href="assets/embedded-reader.css?v={build_id}">
</head>
<body>
<header class="site-return-bar">
<a href="index.html" class="exit" aria-label="Return to catalogue" title="Return to catalogue">×</a>
<a id="backToTitle" class="manga-title" href="index.html" title="Return to manga page">Loading reader…</a>
</header>
<main id="readerArea"><p id="readerStatus" role="status">Loading Cubari…</p></main>
<script src="assets/embedded-reader.js?v={build_id}"></script>
</body></html>"""
    embedded_css = """
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#15171b;color:#eee;font:14px system-ui,sans-serif}body{display:flex;flex-direction:column;height:100vh;height:100dvh;padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)}[hidden]{display:none!important}.site-return-bar{flex:0 0 auto;display:grid;grid-template-columns:44px minmax(0,1fr) 44px;align-items:center;min-height:34px;background:#1d2025;border-bottom:1px solid #34383e;padding:0 8px;gap:6px}.site-return-bar a{color:inherit;text-decoration:none;line-height:1.2;min-width:0}.site-return-bar a:focus-visible{outline:2px solid #eee;outline-offset:-2px}.site-return-bar a:hover{color:#fff;background:#30343b}.exit{justify-self:start;font-size:23px;padding:3px 10px}.manga-title{grid-column:2;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:8px 0}#readerArea{position:relative;flex:1 1 auto;min-height:0;min-width:0;display:flex;align-items:center;justify-content:center}#readerArea iframe{display:block;border:0;width:100%;height:100%;min-height:0;flex:1 1 auto}#readerStatus{padding:1rem;text-align:center;max-width:40rem;line-height:1.5}@media(max-width:540px){.site-return-bar{grid-template-columns:44px minmax(0,1fr) 44px;min-height:40px}.exit{padding:7px 10px}}@media(pointer:coarse){.site-return-bar{min-height:44px}.exit{min-height:44px;display:flex;align-items:center;justify-content:center;min-width:40px}}
"""
    embedded_js = r"""
const params=new URLSearchParams(location.search);
const id=params.get('id'), number=params.get('chapter');
const area=document.querySelector('#readerArea'), status=document.querySelector('#readerStatus');
const back=document.querySelector('#backToTitle');
function titleUrl(){return `title.html?id=${encodeURIComponent(id)}`}
function safeCubariURL(value){try{const u=new URL(value);return u.origin==='https://cubari.moe'&&!u.username&&!u.password&&/^\/read\/[^/]+\/[^/]+\/[^/]+\/[^/]+\/?$/.test(u.pathname)?u:null}catch{return null}}
async function openChapter(){
  if(!id||!number)throw new Error('Missing title or chapter. Return to the catalogue and select a chapter.');
  back.href=titleUrl();back.textContent='Back to manga';
  const r=await fetch(`data/titles/${encodeURIComponent(id)}.json`,{cache:'no-store'});if(!r.ok)throw new Error('Title not found.');
  const t=await r.json(),ch=(t.chapters||[]).find(c=>String(c.number)===number);
  if(!ch)throw new Error('Chapter not found.');
  if(ch.custom_reader && params.get('embedded')!=='1'){
    const next=new URL('cubari/reader.html',location.href);next.searchParams.set('id',id);next.searchParams.set('chapter',number);if(params.has('page'))next.searchParams.set('page',params.get('page'));location.href=next.href;return;
  }
  const url=safeCubariURL(ch.cubari_url);if(!url)throw new Error('No valid Cubari reader link is available for this chapter.');
  const page=params.get('page');if(page&&/^[1-9]\d*$/.test(page)){url.pathname=url.pathname.replace(/\/[^/]+\/?$/,`/${page}/`)}
  back.textContent=t.title;document.title=`${t.title} — Chapter ${number}`;
  const frame=document.createElement('iframe');frame.title=`Cubari reader: ${t.title}, Chapter ${number}`;
  // Keep the original reader usable, but do not grant browser download permission.
  frame.setAttribute('sandbox','allow-scripts allow-same-origin allow-forms allow-popups');
  frame.allow='fullscreen';frame.allowFullscreen=true;frame.referrerPolicy='strict-origin-when-cross-origin';
  frame.src=url.href;area.replaceChildren(frame);
}
openChapter().catch(e=>{status.textContent=e.message;status.setAttribute('role','alert')});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&id)location.href=titleUrl()});
"""
    (GENERATED_DIR / "cubari-reader.html").write_text(embedded_html, encoding="utf-8")
    (GENERATED_DIR / "assets" / "embedded-reader.css").write_text(embedded_css, encoding="utf-8")
    (GENERATED_DIR / "assets" / "embedded-reader.js").write_text(embedded_js, encoding="utf-8")
    (GENERATED_DIR / "index.html").write_text(index_html, encoding="utf-8")
    (GENERATED_DIR / "title.html").write_text(title_html, encoding="utf-8")
    # Keep both historical entry points; both serve the identical embedded reader.
    (GENERATED_DIR / "reader.html").write_text(embedded_html, encoding="utf-8")
    (GENERATED_DIR / "404.html").write_text(index_html, encoding="utf-8")
    (GENERATED_DIR / "assets" / "site.css").write_text(css, encoding="utf-8")
    (GENERATED_DIR / "assets" / "catalog.js").write_text(catalog_js, encoding="utf-8")
    (GENERATED_DIR / "assets" / "title.js").write_text(title_js, encoding="utf-8")
    (GENERATED_DIR / "assets" / "placeholder-cover.svg").write_text(placeholder, encoding="utf-8")
