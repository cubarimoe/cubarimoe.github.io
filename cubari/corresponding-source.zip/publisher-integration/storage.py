from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
CACHE_DIR = DATA_DIR / "cache"
METADATA_DIR = CACHE_DIR / "metadata"
COVERS_DIR = CACHE_DIR / "covers"
GENERATED_DIR = DATA_DIR / "generated_site"
CONFIG_FILE = DATA_DIR / "config.json"
LIBRARY_FILE = DATA_DIR / "library.json"
MAPPINGS_FILE = DATA_DIR / "mappings.json"
PUBLISH_STATE_FILE = DATA_DIR / "publish_state.json"
CREDENTIALS_FILE = DATA_DIR / "credentials.json"


def ensure_dirs() -> None:
    for path in (DATA_DIR, CACHE_DIR, METADATA_DIR, COVERS_DIR, GENERATED_DIR):
        path.mkdir(parents=True, exist_ok=True)


def default_config() -> dict[str, Any]:
    pinokio_root = Path(os.environ.get("PINOKIO_HOME", r"C:\pinokio"))
    return {
        "source_paths": {
            "manga_library": str(pinokio_root / "api" / "CubariMangaLibrary" / "data"),
            "gist_helper": str(pinokio_root / "api" / "CubariGistHelper" / "data"),
        },
        "site": {
            "eyebrow": "CUBARI RELEASE CATALOGUE",
            "name": "Cubari Manga Library",
            "browser_title": "Cubari Manga Library",
            "subtitle": "Read our releases here or view the series on MangaDex.",
            "footer": "Metadata is cached from MangaDex at publication time. Recent updates use Cubari-side dates only.",
            "search_placeholder": "Search titles, tags, authors…",
            "tags_heading": "Browse by tag",
            "read_mangadex_label": "Read on MangaDex",
            "latest_release_label": "Latest Cubari release",
            "last_update_label": "Last Cubari update",
            "accent": "#ff6740",
            "show_unmapped": True,
            "show_tag_filters": True,
            "tag_match_mode": "any",
            "max_card_tags": 3,
            "modified_cubari_enabled": False,
            "chapter_preview_rows": 2,
            "chapter_group_size": 100,
        },
        "mangadex": {
            "preferred_language": "en",
            "cover_size": 512,
        },
        "github": {
            "owner": "",
            "repository": "cubari-manga-site",
            "branch": "main",
            "pages_path": "/",
            "private": False,
            "commit_name": "Cubari Site Publisher",
            "commit_email": "cubari-site-publisher@users.noreply.github.com",
        },
    }


def load_json(path: Path, default: Any) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
    temp.replace(path)


def load_credentials() -> dict[str, Any]:
    ensure_dirs()
    data = load_json(CREDENTIALS_FILE, {})
    return data if isinstance(data, dict) else {}


def save_credentials(data: dict[str, Any]) -> None:
    payload = data if isinstance(data, dict) else {}
    save_json(CREDENTIALS_FILE, payload)


def delete_credentials() -> bool:
    try:
        CREDENTIALS_FILE.unlink()
        return True
    except FileNotFoundError:
        return False


def load_config() -> dict[str, Any]:
    ensure_dirs()
    default = default_config()
    current = load_json(CONFIG_FILE, {})
    merged = _sanitize_config(deep_merge(default, current if isinstance(current, dict) else {}))
    # Rewrite old config.json files once so the removed credentials path is scrubbed from disk.
    if isinstance(current, dict) and (current.get("source_paths") or {}).get("credentials_file"):
        save_json(CONFIG_FILE, merged)
    return merged


def _sanitize_config(config: dict[str, Any]) -> dict[str, Any]:
    clean = deep_merge({}, config if isinstance(config, dict) else {})
    sources = clean.get("source_paths")
    if isinstance(sources, dict):
        # Legacy Gist Helper credential paths are never retained.
        sources.pop("credentials_file", None)
    site = clean.get("site")
    if isinstance(site, dict):
        site.pop("reader_type", None)
        site.pop("show_imgchest_views", None)
    return clean


def save_config(config: dict[str, Any]) -> None:
    save_json(CONFIG_FILE, _sanitize_config(config))


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


ensure_dirs()
if not CONFIG_FILE.exists():
    save_config(default_config())
