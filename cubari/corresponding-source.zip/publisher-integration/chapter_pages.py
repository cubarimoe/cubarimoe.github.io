"""Optional chapter statistics from Cubari. No image downloads or native page cache."""
from __future__ import annotations
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlsplit
import requests
from storage import CACHE_DIR, load_json, save_json

IMG_CHEST_RE = re.compile(r"(?:imgchest\.com/(?:p|api/imgchest/chapter)/|/proxy/api/imgchest/chapter/)([A-Za-z0-9]+)", re.I)

def extract_imgchest_id(value: Any) -> str:
    match = IMG_CHEST_RE.search(str(value or ""))
    return match.group(1) if match else ""

def _cubari_count_path(album_id: str):
    return CACHE_DIR / "cubari_counts" / f"{album_id}.json"

def load_cubari_count(album_id: str, source_updated: int = 0) -> int:
    if not re.fullmatch(r"[A-Za-z0-9]+", album_id):
        return 0
    item = load_json(_cubari_count_path(album_id), {})
    if not isinstance(item, dict) or item.get("source_last_updated") != source_updated:
        return 0
    count = item.get("page_count")
    return count if type(count) is int and count > 0 and count != 40 else 0

def _get_cubari_count(album_id: str) -> int:
    if not re.fullmatch(r"[A-Za-z0-9]+", album_id):
        raise ValueError("Invalid album ID")
    response = requests.get(f"https://cubari.moe/proxy/api/imgchest/chapter/{album_id}/", timeout=30,
                            headers={"Accept": "application/json", "User-Agent": "CubariSitePublisher/0.19"})
    response.raise_for_status()
    payload = response.json()
    pages = payload.get("pages") if isinstance(payload, dict) else payload
    if not isinstance(pages, list) or not pages or not all(isinstance(p,str) and urlsplit(p).scheme in ("http","https") and urlsplit(p).netloc for p in pages):
        raise ValueError("Cubari returned an invalid or empty chapter response")
    if len(pages) == 40:
        raise ValueError("40 pages returned; count omitted because previous responses were truncated at 40")
    return len(pages)

def refresh_library_cubari_counts(library: dict[str, Any], *, max_workers: int = 3) -> dict[str, Any]:
    jobs = {}
    for title in library.get("titles", []):
        for ch in title.get("chapters", []):
            album = str(ch.get("imgchest_id") or "")
            if re.fullmatch(r"[A-Za-z0-9]+", album):
                jobs[album] = max(jobs.get(album, 0), int(ch.get("last_updated") or 0))
    result = {"checked":len(jobs),"fetched":0,"errors":[]}
    def work(album, updated):
        count = _get_cubari_count(album)
        save_json(_cubari_count_path(album), {"page_count":count,"source_last_updated":updated,"fetched_at":datetime.now(timezone.utc).isoformat()})
    with ThreadPoolExecutor(max_workers=max(1,min(4,max_workers))) as executor:
        futures={executor.submit(work,album,updated):album for album,updated in jobs.items()}
        for future in as_completed(futures):
            try:
                future.result(); result["fetched"]+=1
            except Exception as exc:
                result["errors"].append({"album_id":futures[future],"error":str(exc)[:300]})
    return result


def _snapshot_path(album_id):
    return CACHE_DIR / "cubari_reader_manifests" / f"{album_id}.json"


def _valid_pages(pages):
    return isinstance(pages, list) and bool(pages) and all(
        isinstance(x, str) and urlsplit(x).scheme == "https" and bool(urlsplit(x).hostname)
        and not urlsplit(x).username and not urlsplit(x).password and not any(c in x for c in "<>'\"\r\n")
        for x in pages)


def load_reader_pages(chapter):
    # Multiple release groups must stay in the full embedded Cubari reader.
    if int(chapter.get("group_count") or 0) > 1:
        return []
    direct = chapter.get("pages") or []
    if _valid_pages(direct):
        return direct
    album = str(chapter.get("imgchest_id") or "")
    if not re.fullmatch(r"[A-Za-z0-9]+", album):
        return []
    item = load_json(_snapshot_path(album), {})
    pages = item.get("pages") if isinstance(item, dict) else None
    updated = int(chapter.get("last_updated") or 0)
    if not isinstance(item, dict) or item.get("source_last_updated") != updated or not _valid_pages(pages) or len(pages) == 40:
        return []
    return pages


def refresh_cubari_reader_manifests(library, *, max_workers=3):
    jobs = {}
    for title in library.get("titles", []):
        for ch in title.get("chapters", []):
            album = str(ch.get("imgchest_id") or "")
            if re.fullmatch(r"[A-Za-z0-9]+", album) and int(ch.get("group_count") or 0) <= 1:
                jobs[album] = max(jobs.get(album, 0), int(ch.get("last_updated") or 0))
    result = {"checked": len(jobs), "fetched": 0, "reused": 0, "errors": []}
    def work(album, updated):
        # Reuse complete snapshots for unchanged releases; never overwrite with a suspect response.
        if load_reader_pages({"imgchest_id":album,"last_updated":updated}):
            return "reused"
        response = requests.get(f"https://cubari.moe/read/api/imgchest/chapter/{album}/", timeout=30,
                                headers={"Accept":"application/json","User-Agent":"CubariSitePublisher/0.20"})
        response.raise_for_status()
        payload = response.json()
        pages = payload.get("pages") if isinstance(payload, dict) else payload
        if not _valid_pages(pages):
            raise ValueError("Cubari returned invalid or empty page URLs")
        if len(pages) == 40:
            raise ValueError("Ambiguous 40-page response; using embedded Cubari")
        old_count = load_cubari_count(album, updated)
        if old_count > len(pages):
            raise ValueError(f"Cubari returned {len(pages)} pages, previously known {old_count}; using embedded Cubari")
        save_json(_snapshot_path(album), {"pages":pages,"source_last_updated":updated,"fetched_at":datetime.now(timezone.utc).isoformat()})
        save_json(_cubari_count_path(album), {"page_count":len(pages),"source_last_updated":updated})
        return "fetched"
    with ThreadPoolExecutor(max_workers=max(1,min(4,max_workers))) as executor:
        futures = {executor.submit(work,album,updated):album for album,updated in jobs.items()}
        for future in as_completed(futures):
            try:
                result[future.result()] += 1
            except Exception as exc:
                result["errors"].append({"album_id":futures[future],"error":str(exc)[:300]})
    return result
