const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
let appStatus = null;
let config = null;
let titleRows = [];
let activeTitle = null;
let activeEditTitle = null;

const esc = value => String(value ?? '').replace(/[&<>'"]/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
}[char]));

function formatInlineMarkdown(value) {
  return esc(value)
    .replace(/\*\*([^*\n]+?)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*\n]+?)\*(?!\*)/g, '$1<em>$2</em>');
}

function renderSafeMarkdown(value) {
  const text = String(value ?? '').replace(/\r\n?/g, '\n');
  const linkPattern = /\[([^\]\n]+)\]\(((?:https?:\/\/|mailto:)[^\s<>'")]+)\)/gi;
  const output = [];
  let cursor = 0;
  for (const match of text.matchAll(linkPattern)) {
    output.push(formatInlineMarkdown(text.slice(cursor, match.index)));
    output.push(`<a href="${esc(match[2])}" target="_blank" rel="noopener noreferrer">${formatInlineMarkdown(match[1])}</a>`);
    cursor = match.index + match[0].length;
  }
  output.push(formatInlineMarkdown(text.slice(cursor)));
  return output.join('').replace(/\n/g, '<br>');
}

function updateIntroductionPreview() {
  const textarea = $('#siteSubtitle');
  const preview = $('#introductionPreview');
  if (!textarea || !preview) return;
  const value = textarea.value;
  preview.innerHTML = value.trim() ? renderSafeMarkdown(value) : '<span class="small">Your formatted introduction will appear here.</span>';
}

function insertIntroductionMarkdown(action) {
  const textarea = $('#siteSubtitle');
  if (!textarea) return;
  const start = textarea.selectionStart ?? textarea.value.length;
  const end = textarea.selectionEnd ?? start;
  const selected = textarea.value.slice(start, end);
  let replacement = selected;
  let selectStart = start;
  let selectEnd = start;
  if (action === 'bold') {
    const content = selected || 'bold text';
    replacement = `**${content}**`;
    selectStart = start + 2;
    selectEnd = selectStart + content.length;
  } else if (action === 'italic') {
    const content = selected || 'italic text';
    replacement = `*${content}*`;
    selectStart = start + 1;
    selectEnd = selectStart + content.length;
  } else if (action === 'link') {
    const content = selected || 'link text';
    replacement = `[${content}](https://example.com)`;
    selectStart = start + replacement.indexOf('https://');
    selectEnd = selectStart + 'https://example.com'.length;
  }
  textarea.setRangeText(replacement, start, end, 'end');
  textarea.focus();
  textarea.setSelectionRange(selectStart, selectEnd);
  textarea.dispatchEvent(new Event('input', { bubbles: true }));
}

const log = (label, data) => {
  const out = $('#logOutput');
  const stamp = new Date().toLocaleTimeString();
  const text = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
  out.textContent = `[${stamp}] ${label}\n${text}\n\n${out.textContent === 'Ready.' ? '' : out.textContent}`;
};

const toast = (message, error = false) => {
  const element = $('#toast');
  element.textContent = message;
  element.classList.toggle('error', error);
  element.hidden = false;
  clearTimeout(element._timer);
  element._timer = setTimeout(() => { element.hidden = true; }, 4000);
};

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  let data;
  try { data = await response.json(); } catch { data = { detail: await response.text() }; }
  if (!response.ok) throw new Error(data.detail || `HTTP ${response.status}`);
  return data;
}

function busy(button, state, label) {
  if (!button) return;
  if (state) {
    button.dataset.oldText = button.textContent;
    button.textContent = label || 'Working…';
    button.disabled = true;
  } else {
    button.textContent = button.dataset.oldText || button.textContent;
    button.disabled = false;
  }
}

function switchTab(id) {
  $$('.tab').forEach(item => item.classList.toggle('active', item.dataset.tab === id));
  $$('.tab-panel').forEach(item => item.classList.toggle('active', item.id === id));
}

$$('.tab').forEach(item => item.addEventListener('click', () => switchTab(item.dataset.tab)));
$$('[data-goto]').forEach(item => item.addEventListener('click', () => switchTab(item.dataset.goto)));

async function loadStatus() {
  try {
    appStatus = await api('/api/status');
    config = appStatus.config;
    renderStatus();
    renderSavedTokenStatus(appStatus.github_credentials || {});
    fillSettings();
    fillSiteEditor();
    $('#previewLink').classList.toggle('disabled', !appStatus.site_generated);
  } catch (error) {
    toast(error.message, true);
    log('Status error', error.message);
  }
}

function formatDate(value) {
  if (!value) return '';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString();
}

function tokenExpiryText(credentials) {
  if (!credentials?.expires_at) return 'No expiration date reported by GitHub';
  if (credentials.expired) return `Expired: ${formatDate(credentials.expires_at)}`;
  const days = credentials.days_remaining;
  return `${formatDate(credentials.expires_at)}${Number.isInteger(days) ? ` (${days} day${days === 1 ? '' : 's'} remaining)` : ''}`;
}

function renderSavedTokenStatus(credentials = {}) {
  const box = $('#savedTokenStatus');
  const forget = $('#forgetTokenButton');
  if (!box) return;
  if (!credentials.saved) {
    box.classList.remove('warning-notice', 'danger-notice');
    box.innerHTML = '<strong>No token saved.</strong><br>Enter one above and enable “Save this token on this computer,” then test or publish.';
    if (forget) forget.disabled = true;
    return;
  }
  const warning = credentials.expired || (Number.isInteger(credentials.days_remaining) && credentials.days_remaining <= 30);
  box.classList.toggle('warning-notice', warning && !credentials.expired);
  box.classList.toggle('danger-notice', Boolean(credentials.expired));
  box.innerHTML = `<strong>Saved token:</strong> ${esc(credentials.masked || 'Saved')}<br><strong>Account:</strong> ${esc(credentials.authenticated_login || 'Not validated yet')}<br><strong>Expiration:</strong> ${esc(tokenExpiryText(credentials))}${credentials.last_validated_at ? `<br><strong>Last validated:</strong> ${esc(formatDate(credentials.last_validated_at))}` : ''}`;
  if (forget) forget.disabled = false;
}

function renderStatus() {
  const sources = appStatus.library.sources || {};
  const sourceHealth = sources.manga_jsons && sources.history_entries && sources.library_entries;
  const cards = [
    ['Detected titles', appStatus.library.title_count, appStatus.library.title_count ? 'good' : 'warn'],
    ['Imported MD mappings', appStatus.mappings.imported, appStatus.mappings.imported ? 'good' : 'warn'],
    ['Source integration', sourceHealth ? 'Exact app format' : 'Needs scan', sourceHealth ? 'good' : 'warn'],
    ['GitHub token', appStatus.github_credentials?.saved ? (appStatus.github_credentials.expired ? 'Saved, expired' : 'Saved locally') : 'Not saved', appStatus.github_credentials?.saved && !appStatus.github_credentials?.expired ? 'good' : 'warn'],
    ['Reader', 'Cubari — modified frontend', 'good'],
    ['Generated site', appStatus.site_generated ? 'Ready' : 'Not generated', appStatus.site_generated ? 'good' : 'warn'],
    ['Scan errors', appStatus.library.error_count, appStatus.library.error_count ? 'warn' : 'good']
  ];
  $('#statusCards').innerHTML = cards.map(([label, value, cls]) =>
    `<article class="status-card ${cls}"><span>${esc(label)}</span><strong>${esc(value)}</strong></article>`
  ).join('');
}

function fillSettings() {
  if (!config) return;
  const form = $('#settingsForm').elements;
  const sources = config.source_paths || {};
  const md = config.mangadex || {};
  const gh = config.github || {};
  form.manga_library.value = sources.manga_library || '';
  form.gist_helper.value = sources.gist_helper || '';
  form.preferred_language.value = md.preferred_language || 'en';
  form.cover_size.value = String(md.cover_size || 512);
  form.github_owner.value = gh.owner || '';
  form.github_repository.value = gh.repository || 'cubari-manga-site';
  form.github_branch.value = gh.branch || 'main';
  form.github_private.checked = Boolean(gh.private);
  form.github_commit_name.value = gh.commit_name || 'Cubari Site Publisher';
  form.github_commit_email.value = gh.commit_email || 'cubari-site-publisher@users.noreply.github.com';
}

function fillSiteEditor() {
  if (!config) return;
  const form = $('#siteEditorForm').elements;
  const site = config.site || {};
  form.site_eyebrow.value = site.eyebrow || '';
  form.site_name.value = site.name || '';
  form.browser_title.value = site.browser_title || site.name || '';
  form.site_subtitle.value = site.subtitle || '';
  form.site_footer.value = site.footer || '';
  form.search_placeholder.value = site.search_placeholder || '';
  form.tags_heading.value = site.tags_heading || '';
  form.read_mangadex_label.value = site.read_mangadex_label || '';
  form.latest_release_label.value = site.latest_release_label || '';
  form.last_update_label.value = site.last_update_label || '';
  form.site_accent.value = site.accent || '#ff6740';
  form.show_unmapped.checked = site.show_unmapped !== false;
  form.show_tag_filters.checked = site.show_tag_filters !== false;
  form.tag_match_mode.value = site.tag_match_mode || 'any';
  form.max_card_tags.value = String(site.max_card_tags ?? 3);
  form.chapter_preview_rows.value = String(site.chapter_preview_rows ?? 2);
  form.chapter_group_size.value = String(site.chapter_group_size ?? 100);
  updateIntroductionPreview();
}

$('#siteSubtitle')?.addEventListener('input', updateIntroductionPreview);
$$('[data-md-action]').forEach(button => button.addEventListener('click', () => insertIntroductionMarkdown(button.dataset.mdAction)));

async function saveSiteEditor({ silent = false } = {}) {
  const form = $('#siteEditorForm').elements;
  const next = structuredClone(config || {});
  next.site = {
    ...(next.site || {}),
    eyebrow: form.site_eyebrow.value.trim(),
    name: form.site_name.value.trim() || 'Cubari Manga Library',
    browser_title: form.browser_title.value.trim() || form.site_name.value.trim() || 'Cubari Manga Library',
    subtitle: form.site_subtitle.value.trim(),
    footer: form.site_footer.value.trim(),
    search_placeholder: form.search_placeholder.value.trim() || 'Search titles, tags, authors…',
    tags_heading: form.tags_heading.value.trim() || 'Browse by tag',
    read_mangadex_label: form.read_mangadex_label.value.trim() || 'Read on MangaDex',
    latest_release_label: form.latest_release_label.value.trim() || 'Latest Cubari release',
    last_update_label: form.last_update_label.value.trim() || 'Last Cubari update',
    accent: form.site_accent.value || '#ff6740',
    show_unmapped: form.show_unmapped.checked,
    show_tag_filters: form.show_tag_filters.checked,
    tag_match_mode: form.tag_match_mode.value === 'all' ? 'all' : 'any',
    max_card_tags: Number(form.max_card_tags.value) || 0,
    chapter_preview_rows: Math.max(1, Math.min(4, Number(form.chapter_preview_rows.value) || 2)),
    chapter_group_size: [50, 100, 200].includes(Number(form.chapter_group_size.value)) ? Number(form.chapter_group_size.value) : 100
  };
  const data = await api('/api/config', { method: 'POST', body: JSON.stringify({ config: next }) });
  config = data.config;
  if (!silent) {
    toast('Site editor settings saved');
    log('Site editor settings saved', next.site);
  }
  return data;
}

$('#siteEditorForm').addEventListener('submit', async event => {
  event.preventDefault();
  const button = event.submitter;
  busy(button, true, 'Saving…');
  try {
    await saveSiteEditor();
    await loadStatus();
  } catch (error) {
    toast(error.message, true);
  } finally {
    busy(button, false);
  }
});

$('#restoreSiteDefaults').addEventListener('click', async event => {
  const button = event.currentTarget;
  busy(button, true, 'Restoring…');
  try {
    const data = await api('/api/site/reset', { method: 'POST' });
    config = data.config;
    fillSiteEditor();
    toast('Default site text and tag settings restored');
    log('Site editor restored to defaults', config.site);
  } catch (error) {
    toast(error.message, true);
  } finally {
    busy(button, false);
  }
});

$('#editorPreviewButton').addEventListener('click', async event => {
  const button = event.currentTarget;
  busy(button, true, 'Saving and generating…');
  try {
    await saveSiteEditor({ silent: true });
    await generateSite(null, { saveEditor: false });
    window.open('/site/', '_blank');
  } catch (error) {
    toast(error.message, true);
  } finally {
    busy(button, false);
  }
});

$('#detectPathsButton').addEventListener('click', async event => {
  const button = event.currentTarget;
  busy(button, true, 'Detecting…');
  try {
    const data = await api('/api/config/detect', { method: 'POST' });
    config = data.config;
    fillSettings();
    log('Pinokio source detection', data);
    const required = ['manga_library', 'gist_helper'];
    const found = required.filter(key => data.detected?.[key]).length;
    toast(found === required.length ? 'All Cubari app paths detected' : `Detected ${found} of ${required.length} required paths`, found !== required.length);
  } catch (error) {
    toast(error.message, true);
  } finally {
    busy(button, false);
  }
});

$('#settingsForm').addEventListener('submit', async event => {
  event.preventDefault();
  const button = event.submitter;
  const form = event.currentTarget.elements;
  const next = structuredClone(config || {});
  next.source_paths = {
    manga_library: form.manga_library.value.trim(),
    gist_helper: form.gist_helper.value.trim()
  };
  next.mangadex = {
    preferred_language: form.preferred_language.value.trim() || 'en',
    cover_size: Number(form.cover_size.value) || 512
  };
  next.github = {
    ...(next.github || {}),
    owner: form.github_owner.value.trim(),
    repository: form.github_repository.value.trim() || 'cubari-manga-site',
    branch: form.github_branch.value.trim() || 'main',
    pages_path: '/',
    private: form.github_private.checked,
    commit_name: form.github_commit_name.value.trim() || 'Cubari Site Publisher',
    commit_email: form.github_commit_email.value.trim() || 'cubari-site-publisher@users.noreply.github.com'
  };
  busy(button, true, 'Saving…');
  try {
    const data = await api('/api/config', { method: 'POST', body: JSON.stringify({ config: next }) });
    config = data.config;
    toast('Technical settings saved');
    log('Technical settings saved', next);
    await loadStatus();
  } catch (error) {
    toast(error.message, true);
  } finally {
    busy(button, false);
  }
});

async function scanSources({ switchToTitles = true } = {}) {
  const button = $('#scanButton');
  busy(button, true, 'Scanning…');
  try {
    const data = await api('/api/scan', { method: 'POST' });
    log('Local scan complete', data);
    const imported = data.mapping_import?.added || 0;
    toast(`Detected ${data.titles.length} titles; imported ${imported} new MangaDex mappings`);
    await Promise.all([loadStatus(), loadTitles()]);
    if (switchToTitles) switchTab('titles');
    return data;
  } catch (error) {
    toast(error.message, true);
    log('Scan failed', error.message);
    throw error;
  } finally {
    busy(button, false);
  }
}

$('#scanButton').addEventListener('click', () => scanSources());

async function loadTitles() {
  try {
    const data = await api('/api/titles');
    titleRows = data.titles || [];
    renderTitles();
    if (data.errors?.length) log('Scanner warnings', data.errors);
  } catch (error) {
    toast(error.message, true);
    log('Title load failed', error.message);
  }
}

function sourceLabel(title) {
  const types = title.source_types || [];
  const labels = [];
  if (types.includes('gist_manga_json')) labels.push('Cubari JSON');
  if (types.includes('gist_history')) labels.push('Gist history');
  if (types.includes('manga_library_catalog')) labels.push('Manga Library');
  if (types.includes('manga_library_qrcodes')) labels.push('QR data');
  return labels.join(' • ') || 'Unknown source';
}

function effectiveTags(title) {
  const mapping = title.mapping || {};
  const hidden = new Set((mapping.hidden_tags || []).map(tag => tag.toLocaleLowerCase()));
  const result = [];
  const seen = new Set();
  [...(title.mangadex?.tags || []), ...(mapping.custom_tags || [])].forEach(tag => {
    const clean = String(tag || '').trim();
    const key = clean.toLocaleLowerCase();
    if (!clean || hidden.has(key) || seen.has(key)) return;
    seen.add(key);
    result.push(clean);
  });
  return result;
}

function renderTitles() {
  const query = $('#titleFilter').value.trim().toLowerCase();
  const filtered = titleRows.filter(title => [title.title, ...effectiveTags(title)].join(' ').toLowerCase().includes(query));
  $('#titlesEmpty').hidden = titleRows.length !== 0;
  $('#titlesTableWrap').hidden = titleRows.length === 0;
  $('#titlesBody').innerHTML = filtered.map(title => {
    const mapping = title.mapping || {};
    const md = title.mangadex || {};
    const latest = title.latest_chapter || {};
    const tags = effectiveTags(title);
    const mappingSource = mapping.mapping_source === 'gist_helper'
      ? '<span class="tag good">Imported from Gist Helper</span>'
      : mapping.mapping_source === 'manual'
        ? '<span class="tag">Manual</span>'
        : '';
    const hasOverrides = Boolean(mapping.title_override || mapping.description_override || (mapping.custom_tags || []).length || (mapping.hidden_tags || []).length);
    return `<tr>
      <td class="title-cell">
        <strong>${esc(title.title)}</strong>
        <span class="small">${esc(sourceLabel(title))}</span>
        <div><span class="tag">${title.chapter_count} chapters</span>${latest.number ? `<span class="tag">Latest ${esc(latest.number)}</span>` : ''}${hasOverrides ? '<span class="tag override-note">Website overrides</span>' : ''}</div>
      </td>
      <td>${title.cubari_url
        ? `<span class="tag good">Read link found</span><div class="small">${esc(title.cubari_url.slice(0, 72))}${title.cubari_url.length > 72 ? '…' : ''}</div>`
        : '<span class="tag warn">No Cubari link detected</span>'}</td>
      <td>${mapping.mangadex_id
        ? `<strong>${esc(mapping.selected_title || md.title || title.title)}</strong><div class="small">${esc(mapping.mangadex_id)}</div>${mappingSource}`
        : '<span class="tag warn">Not mapped</span>'}${mapping.excluded ? '<div><span class="tag">Excluded</span></div>' : ''}</td>
      <td>${md.id
        ? `<span class="tag good">Cached</span><div class="small">${esc(md.status || '')} ${esc(md.year || '')}</div><div class="metadata-tags">${tags.slice(0, 6).map(tag => `<span class="tag">${esc(tag)}</span>`).join('')}${tags.length > 6 ? `<span class="tag">+${tags.length - 6}</span>` : ''}</div>`
        : '<span class="small">Not refreshed yet</span>'}</td>
      <td><div class="action-row">
        <button class="mini-button edit-title-button" data-id="${title.id}">Edit</button>
        <button class="mini-button map-button" data-id="${title.id}">${mapping.mangadex_id ? 'Change MD' : 'Map MD'}</button>
        ${mapping.mangadex_id ? `<button class="mini-button refresh-one" data-id="${title.id}">Refresh</button>` : ''}
        <button class="mini-button exclude-button" data-id="${title.id}">${mapping.excluded ? 'Include' : 'Exclude'}</button>
      </div></td>
    </tr>`;
  }).join('');
  $$('.edit-title-button').forEach(button => button.addEventListener('click', () => openTitleEditor(button.dataset.id)));
  $$('.map-button').forEach(button => button.addEventListener('click', () => openMapping(button.dataset.id)));
  $$('.refresh-one').forEach(button => button.addEventListener('click', () => refreshMd([button.dataset.id], button)));
  $$('.exclude-button').forEach(button => button.addEventListener('click', () => toggleExclude(button.dataset.id, button)));
}

$('#titleFilter').addEventListener('input', renderTitles);
$('#reloadTitles').addEventListener('click', loadTitles);

async function updateTitleMapping(id, updates) {
  return api(`/api/titles/${id}/mapping`, { method: 'POST', body: JSON.stringify(updates) });
}

async function toggleExclude(id, button) {
  const title = titleRows.find(item => item.id === id);
  const mapping = title.mapping || {};
  busy(button, true);
  try {
    await updateTitleMapping(id, { excluded: !mapping.excluded });
    await Promise.all([loadTitles(), loadStatus()]);
  } catch (error) {
    toast(error.message, true);
  } finally {
    busy(button, false);
  }
}

function parseTags(value) {
  const result = [];
  const seen = new Set();
  String(value || '').split(/[\n,]+/).forEach(raw => {
    const tag = raw.trim();
    const key = tag.toLocaleLowerCase();
    if (tag && !seen.has(key)) { seen.add(key); result.push(tag); }
  });
  return result;
}

function openTitleEditor(id) {
  activeEditTitle = titleRows.find(item => item.id === id);
  if (!activeEditTitle) return;
  const mapping = activeEditTitle.mapping || {};
  const form = $('#titleEditorForm').elements;
  $('#titleEditorHeading').textContent = activeEditTitle.title;
  form.title_override.value = mapping.title_override || '';
  form.description_override.value = mapping.description_override || '';
  form.custom_tags.value = (mapping.custom_tags || []).join('\n');
  form.hidden_tags.value = (mapping.hidden_tags || []).join('\n');
  $('#titleEditorDialog').showModal();
}

function closeTitleEditor() {
  $('#titleEditorDialog').close();
  activeEditTitle = null;
}

$('#closeTitleEditor').addEventListener('click', closeTitleEditor);
$('#cancelTitleEditor').addEventListener('click', closeTitleEditor);
$('#titleEditorForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!activeEditTitle) return;
  const button = $('#saveTitleOverrides');
  const form = event.currentTarget.elements;
  busy(button, true, 'Saving…');
  try {
    await updateTitleMapping(activeEditTitle.id, {
      title_override: form.title_override.value.trim(),
      description_override: form.description_override.value.trim(),
      custom_tags: parseTags(form.custom_tags.value),
      hidden_tags: parseTags(form.hidden_tags.value)
    });
    closeTitleEditor();
    toast('Title website settings saved');
    await loadTitles();
  } catch (error) {
    toast(error.message, true);
  } finally {
    busy(button, false);
  }
});

$('#clearTitleOverrides').addEventListener('click', async event => {
  if (!activeEditTitle) return;
  const button = event.currentTarget;
  busy(button, true, 'Clearing…');
  try {
    await updateTitleMapping(activeEditTitle.id, { title_override: '', description_override: '', custom_tags: [], hidden_tags: [] });
    closeTitleEditor();
    toast('Title overrides cleared');
    await loadTitles();
  } catch (error) {
    toast(error.message, true);
  } finally {
    busy(button, false);
  }
});

function openMapping(id) {
  activeTitle = titleRows.find(item => item.id === id);
  if (!activeTitle) return;
  $('#mappingTitle').textContent = activeTitle.title;
  $('#mdSearchInput').value = activeTitle.title;
  const current = activeTitle.mapping || {};
  $('#mdResults').innerHTML = current.mangadex_id
    ? `<p class="small">Current MangaDex ID: ${esc(current.mangadex_id)}. Search only if this mapping is wrong.</p>`
    : '<p class="small">Press Search to find MangaDex candidates.</p>';
  $('#mappingDialog').showModal();
}

async function searchMd() {
  const query = $('#mdSearchInput').value.trim();
  if (!query) return;
  const button = $('#mdSearchButton');
  busy(button, true, 'Searching…');
  try {
    const data = await api(`/api/mangadex/search?q=${encodeURIComponent(query)}`);
    renderMdResults(data.results || []);
  } catch (error) {
    toast(error.message, true);
    $('#mdResults').innerHTML = `<p class="small">${esc(error.message)}</p>`;
  } finally {
    busy(button, false);
  }
}

function renderMdResults(results) {
  if (!results.length) {
    $('#mdResults').innerHTML = '<p class="small">No matches found.</p>';
    return;
  }
  $('#mdResults').innerHTML = results.map(result => {
    const cover = result.cover?.filename
      ? `https://uploads.mangadex.org/covers/${result.id}/${result.cover.filename}.256.jpg`
      : '';
    return `<article class="md-result">
      ${cover ? `<img src="${esc(cover)}" alt="">` : '<div></div>'}
      <div><h3>${esc(result.title)}</h3><p>${esc([result.original_title, result.year, result.status, (result.authors || []).join(', ')].filter(Boolean).join(' • '))}</p><p>${esc((result.description || '').slice(0, 220))}${(result.description || '').length > 220 ? '…' : ''}</p></div>
      <button class="button primary choose-md" data-id="${result.id}" data-title="${esc(result.title)}">Choose</button>
    </article>`;
  }).join('');
  $$('.choose-md').forEach(button => button.addEventListener('click', () => chooseMd(button.dataset.id, button.dataset.title)));
}

async function chooseMd(mangaId, title) {
  if (!activeTitle) return;
  try {
    await updateTitleMapping(activeTitle.id, { mangadex_id: mangaId, selected_title: title, excluded: false });
    $('#mappingDialog').close();
    toast(`Mapped to ${title}`);
    await Promise.all([loadTitles(), loadStatus()]);
  } catch (error) {
    toast(error.message, true);
  }
}

$('#mdSearchButton').addEventListener('click', searchMd);
$('#mdSearchInput').addEventListener('keydown', event => {
  if (event.key === 'Enter') { event.preventDefault(); searchMd(); }
});
$('#removeMappingButton').addEventListener('click', async () => {
  if (!activeTitle) return;
  try {
    await updateTitleMapping(activeTitle.id, { mangadex_id: '', selected_title: '' });
    $('#mappingDialog').close();
    await Promise.all([loadTitles(), loadStatus()]);
    toast('MangaDex mapping removed and marked as a manual choice');
  } catch (error) {
    toast(error.message, true);
  }
});

async function refreshMd(ids = null, button = $('#refreshMdButton'), { regenerate = true } = {}) {
  busy(button, true, 'Refreshing…');
  try {
    const data = await api('/api/refresh', { method: 'POST', body: JSON.stringify({ ids }) });
    log('MangaDex refresh complete', data);
    const coverText = data.covers_removed ? `; removed covers ${data.covers_removed}` : '';
    toast(`Checked ${data.checked}; metadata changed ${data.updated}; covers updated ${data.covers}${coverText}${data.errors.length ? `; errors ${data.errors.length}` : ''}`, Boolean(data.errors.length));
    await Promise.all([loadTitles(), loadStatus()]);
    if (regenerate) {
      const preview = await generateSite(null, { saveEditor: false });
      toast(`MangaDex refreshed and preview rebuilt with ${preview.tag_count || 0} tag filters`);
    }
    return data;
  } catch (error) {
    toast(error.message, true);
    log('MangaDex refresh failed', error.message);
    throw error;
  } finally {
    busy(button, false);
  }
}

$('#refreshMdButton').addEventListener('click', () => refreshMd());

async function refreshReaderData(button = $('#refreshCubariManifestsButton'), { regenerate = true } = {}) {
  busy(button, true, 'Refreshing reader data…');
  try {
    const data = await api('/api/reader/cubari-manifests', {method:'POST'});
    log('Cubari reader refresh', data);
    toast(`Reader data: ${data.fetched} new, ${data.updated} updated, ${data.unchanged} unchanged, ${data.errors.length} failed`, Boolean(data.errors.length));
    if (regenerate) await generateSite(null, {saveEditor:false});
    return data;
  } catch (error) {
    toast(error.message, true); log('Reader refresh failed', error.message); throw error;
  } finally { busy(button, false); }
}
$('#refreshCubariManifestsButton').addEventListener('click', () => refreshReaderData().catch(() => {}));

async function generateSite(button = $('#generateButton'), { saveEditor = true } = {}) {
  busy(button, true, 'Generating…');
  try {
    if (saveEditor) await saveSiteEditor({ silent: true });
    const data = await api('/api/generate', { method: 'POST' });
    log('Website generated', data);
    toast(`Generated ${data.title_count} title pages, ${data.tag_count || 0} tag filters, and ${data.custom_cubari_chapters || 0} prepared chapters (${data.embedded_reader_chapters || 0} fallback)`);
    $('#previewLink').classList.remove('disabled');
    await loadStatus();
    return data;
  } catch (error) {
    toast(error.message, true);
    log('Generation failed', error.message);
    throw error;
  } finally {
    busy(button, false);
  }
}

const dashboardGenerateButton = $('#generateButton');
if (dashboardGenerateButton) dashboardGenerateButton.addEventListener('click', () => generateSite());

function githubPayload() {
  return {
    token: $('#manualToken').value,
    remember: $('#rememberToken').checked
  };
}

function applyCredentialResult(credentials) {
  if (!credentials) return;
  if (appStatus) appStatus.github_credentials = credentials;
  renderSavedTokenStatus(credentials);
  if (credentials.saved) $('#rememberToken').checked = false;
}

async function testGithub() {
  const button = $('#testGithubButton');
  busy(button, true, 'Testing…');
  try {
    const data = await api('/api/github/test', { method: 'POST', body: JSON.stringify(githubPayload()) });
    log('GitHub connection', data);
    const actor = data.authenticated_account || {};
    const target = data.publish_target || {};
    applyCredentialResult(data.credentials);
    const result = $('#githubTestResult');
    result.hidden = false;
    result.innerHTML = `<strong>Token account:</strong> ${esc(actor.login || 'Unknown')}<br><strong>Publishing target:</strong> ${esc(target.full_name || `${target.owner || ''}/${target.repository || ''}`)}<br><strong>Token source:</strong> ${esc(data.source === 'saved' ? 'Saved local token' : 'Token entered above')}<br><strong>Expiration:</strong> ${esc(data.token_expiration ? formatDate(data.token_expiration) : 'No expiration date reported by GitHub')}<br><strong>Commit identity:</strong> ${esc(data.neutral_commit_identity?.name || 'Cubari Site Publisher')} &lt;${esc(data.neutral_commit_identity?.email || '')}&gt;`;
    if (!target.exists) {
      toast('Token works, but the configured organization repository was not found', true);
    } else if (target.empty) {
      toast(`Ready to initialize ${target.full_name || 'the organization repository'}`);
    } else if (target.can_push === false) {
      toast('Repository found, but write access was not confirmed', true);
    } else {
      toast(`Ready to publish to ${target.full_name || 'the organization repository'}`);
    }
  } catch (error) {
    toast(error.message, true);
    log('GitHub test failed', error.message);
  } finally {
    busy(button, false);
  }
}

$('#testGithubButton').addEventListener('click', testGithub);
$('#forgetTokenButton').addEventListener('click', async event => {
  const button = event.currentTarget;
  if (!confirm('Delete the saved GitHub token from this computer?')) return;
  busy(button, true, 'Forgetting…');
  try {
    const data = await api('/api/github/credentials', { method: 'DELETE' });
    applyCredentialResult(data.credentials || {});
    $('#manualToken').value = '';
    $('#githubTestResult').hidden = true;
    toast(data.removed ? 'Saved GitHub token deleted' : 'No saved token was present');
    await loadStatus();
  } catch (error) {
    toast(error.message, true);
  } finally {
    busy(button, false);
    renderSavedTokenStatus(appStatus?.github_credentials || {});
  }
});

async function publishSite(button = $('#publishButton')) {
  busy(button, true, 'Publishing…');
  try {
    const generated = await generateSite(null);
    const warnings = generated.reader_warnings || [];
    if (warnings.length) {
      const sample = warnings.slice(0, 8).map(w => `${w.title} — chapter ${w.chapter}`).join('\n');
      if (!window.confirm(`${warnings.length} chapter(s) have no valid Cubari link and will be unavailable.\n\n${sample}\n\nPublish with these unavailable chapters? Cancel to check the source JSON first.`)) return;
    }
    const data = await api('/api/github/publish', { method: 'POST', body: JSON.stringify({...githubPayload(), allow_reader_fallbacks: warnings.length > 0}) });
    log('Published to GitHub', data);
    const result = $('#publishedResult');
    result.hidden = false;
    const actor = data.authenticated_account || {};
    const target = data.publish_target || {};
    applyCredentialResult(data.credentials);
    result.innerHTML = `<strong>Published successfully to ${esc(target.full_name || `${data.owner}/${data.repository}`)}.</strong><p>Token account: ${esc(actor.login || 'Unknown')}<br>Token source: ${esc(data.token_source === 'saved' ? 'Saved local token' : 'Token entered above')}<br>Commit author: ${esc(data.publish?.commit_identity?.name || 'Cubari Site Publisher')}</p><p><a href="${esc(data.site_url)}" target="_blank">Open GitHub Pages website</a><br><a href="${esc(data.repository_url)}" target="_blank">Open repository</a></p>${data.pages?.configured ? '' : '<p>Files were published, but automatic Pages setup was not confirmed. The token may lack Pages or Administration permission.</p>'}`;
    toast('Website published');
    return data;
  } catch (error) {
    toast(error.message, true);
    log('Publishing failed', error.message);
    throw error;
  } finally {
    busy(button, false);
  }
}

$('#publishButton').addEventListener('click', () => publishSite());
$('#fullPublishButton').addEventListener('click', async event => {
  const button = event.currentTarget;
  busy(button, true, 'Running full update…');
  try {
    await saveSiteEditor({ silent: true });
    await scanSources({ switchToTitles: false });
    await refreshMd(null, null, { regenerate: false });
    const readerRefresh = await refreshReaderData(null, { regenerate: false });
    if (readerRefresh.errors.length && !window.confirm(`${readerRefresh.errors.length} Cubari album(s) could not be refreshed. Existing valid cache entries are retained; unavailable entries use the embedded reader. See Results for details. Publish anyway?`)) return;
    await publishSite(null);
  } catch {
    // Individual workflow functions already show the error.
  } finally {
    busy(button, false);
  }
});

$('#refreshStatus').addEventListener('click', async () => {
  await Promise.all([loadStatus(), loadTitles()]);
  toast('Status refreshed');
});
$('#clearLog').addEventListener('click', () => { $('#logOutput').textContent = 'Ready.'; });

loadStatus();
loadTitles();
