from __future__ import annotations

import argparse
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

import uvicorn
from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from chapter_pages import refresh_cubari_reader_manifests
from github_client import GitHubClient
from mangadex import MangaDexClient, MangaDexError, load_cached_metadata
from site_generator import generate_site
from source_scanner import (
    detect_pinokio_sources,
    load_library,
    scan_source_paths,
)
from storage import (
    COVERS_DIR,
    GENERATED_DIR,
    MAPPINGS_FILE,
    PUBLISH_STATE_FILE,
    delete_credentials,
    default_config,
    load_config,
    load_credentials,
    load_json,
    save_config,
    save_credentials,
    save_json,
)

APP_DIR = Path(__file__).resolve().parent
STATIC_DIR = APP_DIR / "static"
VERSION = "0.21.1"

app = FastAPI(title="Cubari Site Publisher", version=VERSION)


class ConfigPayload(BaseModel):
    config: dict[str, Any]


class MappingPayload(BaseModel):
    mangadex_id: str | None = None
    selected_title: str | None = None
    excluded: bool | None = None
    title_override: str | None = None
    description_override: str | None = None
    custom_tags: list[str] | None = None
    hidden_tags: list[str] | None = None


class RefreshPayload(BaseModel):
    ids: list[str] | None = None


class GitHubPayload(BaseModel):
    token: str = Field(default="", repr=False)
    remember: bool = False
    allow_reader_fallbacks: bool = False


def _config() -> dict[str, Any]:
    return load_config()


def _mappings() -> dict[str, Any]:
    data = load_json(MAPPINGS_FILE, {})
    return data if isinstance(data, dict) else {}


def _token_from_request(token: str = "") -> tuple[str, str]:
    if token.strip():
        return token.strip(), "entered"
    saved = load_credentials()
    saved_token = str(saved.get("github_token") or "").strip()
    if saved_token:
        return saved_token, "saved"
    return "", "none"


def _parse_expiration(value: str) -> datetime | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    candidates = [raw, raw.replace("Z", "+00:00")]
    for candidate in candidates:
        try:
            parsed = datetime.fromisoformat(candidate)
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    for pattern in ("%Y-%m-%d %H:%M:%S %Z", "%Y-%m-%d %H:%M:%S"):
        try:
            parsed = datetime.strptime(raw, pattern)
            return parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    try:
        parsed = parsedate_to_datetime(raw)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError, OverflowError):
        return None


def _credentials_status() -> dict[str, Any]:
    credentials = load_credentials()
    token = str(credentials.get("github_token") or "")
    expires_raw = str(credentials.get("expires_at") or "")
    expires = _parse_expiration(expires_raw)
    now = datetime.now(timezone.utc)
    days_remaining = None
    expired = False
    if expires:
        seconds = (expires.astimezone(timezone.utc) - now).total_seconds()
        days_remaining = max(-1, int(seconds // 86400))
        expired = seconds <= 0
    return {
        "saved": bool(token),
        "masked": f"••••••••{token[-4:]}" if token else "",
        "authenticated_login": str(credentials.get("authenticated_login") or ""),
        "expires_at": expires_raw,
        "days_remaining": days_remaining,
        "expired": expired,
        "last_validated_at": str(credentials.get("last_validated_at") or ""),
        "updated_at": str(credentials.get("updated_at") or ""),
    }


def _record_validated_token(
    token: str,
    source: str,
    remember: bool,
    user: dict[str, Any],
    auth_info: dict[str, Any],
) -> dict[str, Any]:
    should_store = source == "saved" or remember
    if should_store:
        now = datetime.now(timezone.utc).isoformat()
        existing = load_credentials()
        payload = {
            **existing,
            "github_token": token,
            "authenticated_login": str(user.get("login") or ""),
            "expires_at": str(auth_info.get("expires_at") or ""),
            "last_validated_at": now,
            "updated_at": now if remember or not existing.get("updated_at") else existing.get("updated_at"),
        }
        save_credentials(payload)
    return _credentials_status()


def _effective_mapping(local: dict[str, Any], mappings: dict[str, Any]) -> dict[str, Any]:
    mapping = dict(mappings.get(local.get("id"), {}) or {})
    if not mapping.get("mangadex_id") and mapping.get("mapping_source") != "manual" and local.get("mangadex_id"):
        mapping["mangadex_id"] = local.get("mangadex_id")
        mapping["selected_title"] = mapping.get("selected_title") or local.get("title", "")
        mapping["mapping_source"] = "gist_helper"
    return mapping


def _pages_site_url(owner: str, repository: str) -> str:
    if repository.casefold() == f"{owner}.github.io".casefold():
        return f"https://{owner}.github.io/"
    return f"https://{owner}.github.io/{repository}/"


def _clean_tags(values: list[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        tag = str(value).strip()
        key = tag.casefold()
        if tag and key not in seen:
            seen.add(key)
            result.append(tag)
    return result


@app.get("/api/status")
def status() -> dict[str, Any]:
    config = _config()
    library = load_library()
    mappings = _mappings()
    generated = (GENERATED_DIR / "index.html").exists()
    effective = [_effective_mapping(item, mappings) for item in library.get("titles") or []]
    return {
        "version": VERSION,
        "config": config,
        "library": {
            "title_count": len(library.get("titles") or []),
            "files_seen": library.get("files_seen", 0),
            "scanned_at": library.get("scanned_at", 0),
            "error_count": len(library.get("errors") or []),
            "sources": library.get("sources") or {},
        },
        "mappings": {
            "mapped": sum(1 for value in effective if value.get("mangadex_id")),
            "imported": sum(1 for value in effective if value.get("mangadex_id") and value.get("mapping_source") == "gist_helper"),
            "manual": sum(1 for value in effective if value.get("mangadex_id") and value.get("mapping_source") == "manual"),
            "excluded": sum(1 for value in effective if value.get("excluded")),
        },
        "github_token_policy": "Optional local credentials.json; never read from Cubari Gist Helper",
        "github_credentials": _credentials_status(),
        "github_target": config.get("github") or {},
        "site_generated": generated,
        "preview_url": "/site/" if generated else "",
    }


@app.get("/api/config")
def get_config() -> dict[str, Any]:
    return _config()


@app.post("/api/config")
def update_config(payload: ConfigPayload) -> dict[str, Any]:
    config = payload.config
    if not isinstance(config, dict):
        raise HTTPException(400, "Invalid configuration")
    save_config(config)
    return {"saved": True, "config": load_config()}


@app.get("/api/site/defaults")
def site_defaults() -> dict[str, Any]:
    return {"site": default_config().get("site", {})}


@app.post("/api/site/reset")
def reset_site_settings() -> dict[str, Any]:
    config = _config()
    config["site"] = default_config().get("site", {})
    save_config(config)
    return {"saved": True, "config": load_config()}


@app.post("/api/config/detect")
def detect_sources() -> dict[str, Any]:
    detected = detect_pinokio_sources()
    config = _config()
    sources = config.setdefault("source_paths", {})
    for key in ("manga_library", "gist_helper"):
        value = detected.get(key, "")
        if value:
            sources[key] = value
    save_config(config)
    return {"detected": detected, "config": config}


@app.post("/api/scan")
def scan() -> dict[str, Any]:
    config = _config()
    sources = config.get("source_paths") or {}
    result = scan_source_paths([sources.get("manga_library", ""), sources.get("gist_helper", "")])

    return result


@app.get("/api/titles")
def titles() -> dict[str, Any]:
    library = load_library()
    mappings = _mappings()
    result = []
    for item in library.get("titles") or []:
        mapping = _effective_mapping(item, mappings)
        manga_id = mapping.get("mangadex_id", "")
        cached = load_cached_metadata(manga_id) if manga_id else {}
        result.append({**item, "mapping": mapping, "mangadex": cached})
    return {"titles": result, "errors": library.get("errors") or [], "sources": library.get("sources") or {}}


@app.get("/api/mangadex/search")
def mangadex_search(q: str) -> dict[str, Any]:
    if not q.strip():
        return {"results": []}
    config = _config()
    language = (config.get("mangadex") or {}).get("preferred_language", "en")
    try:
        results = MangaDexClient(language).search(q.strip())
        return {"results": results}
    except MangaDexError as exc:
        raise HTTPException(502, str(exc)) from exc


@app.post("/api/titles/{title_id}/mapping")
def save_mapping(title_id: str, payload: MappingPayload) -> dict[str, Any]:
    mappings = _mappings()
    current = dict(mappings.get(title_id, {}) or {})
    updates = payload.model_dump(exclude_none=True)
    if not current.get("mangadex_id") and "mangadex_id" not in updates:
        local = next((item for item in (load_library().get("titles") or []) if item.get("id") == title_id), None)
        if local and local.get("mangadex_id"):
            current["mangadex_id"] = local.get("mangadex_id")
            current["selected_title"] = local.get("title", "")
    if "custom_tags" in updates:
        updates["custom_tags"] = _clean_tags(updates["custom_tags"])
    if "hidden_tags" in updates:
        updates["hidden_tags"] = _clean_tags(updates["hidden_tags"])
    current.update(updates)
    if "mangadex_id" in updates or "selected_title" in updates:
        current["mapping_source"] = "manual"
    elif not current.get("mapping_source"):
        current["mapping_source"] = "gist_helper" if current.get("mangadex_id") else "manual"
    mappings[title_id] = current
    save_json(MAPPINGS_FILE, mappings)
    return {"saved": True, "mapping": current}


@app.post("/api/refresh")
def refresh_mangadex(payload: RefreshPayload = Body(default=RefreshPayload())) -> dict[str, Any]:
    config = _config()
    library = load_library()
    mappings = _mappings()
    wanted = set(payload.ids or [])
    language = (config.get("mangadex") or {}).get("preferred_language", "en")
    cover_size = int((config.get("mangadex") or {}).get("cover_size", 512))
    client = MangaDexClient(language)
    summary = {"checked": 0, "updated": 0, "covers": 0, "covers_removed": 0, "errors": []}

    for local in library.get("titles") or []:
        title_id = local.get("id")
        if wanted and title_id not in wanted:
            continue
        mapping = _effective_mapping(local, mappings)
        manga_id = mapping.get("mangadex_id")
        if not manga_id or mapping.get("excluded"):
            continue
        summary["checked"] += 1
        try:
            before = load_cached_metadata(manga_id)
            old_cover = (before.get("cover") or {}).get("filename") if isinstance(before, dict) else ""
            metadata = client.get(manga_id)
            before_compare = dict(before) if isinstance(before, dict) else {}
            after_compare = dict(metadata)
            before_compare.pop("refreshed_at", None)
            after_compare.pop("refreshed_at", None)
            if before_compare != after_compare:
                summary["updated"] += 1
            new_cover = (metadata.get("cover") or {}).get("filename")
            cover_target = COVERS_DIR / f"{manga_id}.jpg"
            if new_cover and (new_cover != old_cover or not cover_target.exists()):
                client.download_cover(metadata, cover_size)
                summary["covers"] += 1
            elif not new_cover and cover_target.exists():
                cover_target.unlink(missing_ok=True)
                summary["covers_removed"] += 1
        except Exception as exc:
            summary["errors"].append({"id": title_id, "title": local.get("title", title_id), "error": str(exc)})
    return summary


@app.post("/api/reader/cubari-manifests")
def refresh_cubari_manifests() -> dict[str, Any]:
    return refresh_cubari_reader_manifests(load_library(), force=True)


@app.post("/api/generate")
def generate() -> dict[str, Any]:
    result = generate_site(_config(), load_library(), _mappings())
    save_json(PUBLISH_STATE_FILE, {"last_generate": result})
    return result


@app.get("/api/github/credentials")
def github_credentials() -> dict[str, Any]:
    return _credentials_status()


@app.delete("/api/github/credentials")
def github_credentials_delete() -> dict[str, Any]:
    removed = delete_credentials()
    return {"removed": removed, "credentials": _credentials_status()}


@app.post("/api/github/test")
def github_test(payload: GitHubPayload) -> dict[str, Any]:
    token, source = _token_from_request(payload.token)
    if not token:
        raise HTTPException(400, "No GitHub token is available. Enter a token, or save one on this computer first.")
    try:
        client = GitHubClient(token)
        user = client.current_user()
        credentials = _record_validated_token(token, source, payload.remember, user, client.last_auth_info)
        github = (_config().get("github") or {})
        owner = github.get("owner") or user.get("login")
        repository = github.get("repository") or "cubari-manga-site"
        branch = github.get("branch") or "main"
        target = client.inspect_repository(owner, repository, branch)
        return {
            "ok": True,
            "authenticated_account": {"login": user.get("login", ""), "name": user.get("name", "")},
            "source": source,
            "credentials": credentials,
            "token_expiration": client.last_auth_info.get("expires_at", ""),
            "publish_target": target,
            "neutral_commit_identity": {
                "name": github.get("commit_name") or "Cubari Site Publisher",
                "email": github.get("commit_email") or "cubari-site-publisher@users.noreply.github.com",
            },
        }
    except Exception as exc:
        raise HTTPException(502, str(exc)) from exc


@app.post("/api/github/publish")
def github_publish(payload: GitHubPayload) -> dict[str, Any]:
    # Regenerate to replace previous reader files and remove old image lists.
    config = _config()
    generated = generate_site(config, load_library(), _mappings())
    warnings = generated.get("reader_warnings", [])
    if warnings and not payload.allow_reader_fallbacks:
        raise HTTPException(409, f"{len(warnings)} chapter(s) have no valid Cubari link. Check the source JSON or explicitly approve publication with unavailable chapters.")
    github = config.get("github") or {}
    token, source = _token_from_request(payload.token)
    if not token:
        raise HTTPException(400, "No GitHub token is available. Enter a token, or save one on this computer first.")
    try:
        client = GitHubClient(token)
        user = client.current_user()
        credentials = _record_validated_token(token, source, payload.remember, user, client.last_auth_info)
        owner = github.get("owner") or user.get("login")
        repository = github.get("repository") or "cubari-manga-site"
        branch = github.get("branch") or "main"
        client.ensure_repository(owner, repository, bool(github.get("private", False)))
        publish = client.publish_directory(
            owner,
            repository,
            branch,
            GENERATED_DIR,
            "Update Cubari manga website",
            github.get("commit_name") or "Cubari Site Publisher",
            github.get("commit_email") or "cubari-site-publisher@users.noreply.github.com",
        )
        try:
            pages = client.enable_pages(owner, repository, branch, github.get("pages_path") or "/")
        except Exception as exc:
            pages = {"configured": False, "message": str(exc)}
        target = client.inspect_repository(owner, repository, branch)
        result = {
            "ok": True,
            "authenticated_account": {"login": user.get("login", ""), "name": user.get("name", "")},
            "publish_target": target,
            "owner": owner,
            "repository": repository,
            "token_source": source,
            "credentials": credentials,
            "token_expiration": client.last_auth_info.get("expires_at", ""),
            "publish": publish,
            "reader_warnings": warnings,
            "pages": pages,
            "site_url": _pages_site_url(owner, repository),
            "repository_url": f"https://github.com/{owner}/{repository}",
        }
        save_json(PUBLISH_STATE_FILE, {"last_publish": result})
        return result
    except Exception as exc:
        raise HTTPException(502, str(exc)) from exc


@app.post("/api/cache/clear")
def clear_cache() -> dict[str, Any]:
    from storage import CACHE_DIR

    removed = 0
    for child in CACHE_DIR.rglob("*"):
        if child.is_file():
            child.unlink(missing_ok=True)
            removed += 1
    return {"removed_files": removed}


@app.middleware("http")
async def disable_preview_cache(request, call_next):
    response = await call_next(request)
    if request.url.path.startswith(("/site", "/admin", "/api")):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


@app.get("/")
def root() -> RedirectResponse:
    return RedirectResponse("/admin/")


app.mount("/site", StaticFiles(directory=str(GENERATED_DIR), html=True), name="site")
app.mount("/admin", StaticFiles(directory=str(STATIC_DIR), html=True), name="admin")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8189)
    args = parser.parse_args()
    print(f"Cubari Site Publisher running at http://{args.host}:{args.port}", flush=True)
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
