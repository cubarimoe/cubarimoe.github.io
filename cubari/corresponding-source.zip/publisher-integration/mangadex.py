from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import requests

from storage import METADATA_DIR, COVERS_DIR, load_json, save_json

API_BASE = "https://api.mangadex.org"
UPLOADS_BASE = "https://uploads.mangadex.org"
USER_AGENT = "CubariSitePublisher/0.16 (static site metadata cache)"


class MangaDexError(RuntimeError):
    pass


class MangaDexClient:
    def __init__(self, preferred_language: str = "en", timeout: int = 30) -> None:
        self.preferred_language = preferred_language or "en"
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT, "Accept": "application/json"})
        self._last_request = 0.0

    def _request(self, method: str, url: str, **kwargs: Any) -> requests.Response:
        elapsed = time.monotonic() - self._last_request
        if elapsed < 0.25:
            time.sleep(0.25 - elapsed)
        try:
            response = self.session.request(method, url, timeout=self.timeout, **kwargs)
        except requests.RequestException as exc:
            self._last_request = time.monotonic()
            raise MangaDexError(f"Could not connect to MangaDex: {exc}") from exc
        self._last_request = time.monotonic()
        if response.status_code >= 400:
            detail = ""
            try:
                payload = response.json()
                detail = json.dumps(payload, ensure_ascii=False)[:500]
            except Exception:
                detail = response.text[:500]
            raise MangaDexError(f"MangaDex returned HTTP {response.status_code}: {detail}")
        return response

    def search(self, title: str, limit: int = 10) -> list[dict[str, Any]]:
        params = [
            ("title", title),
            ("limit", str(max(1, min(limit, 20)))),
            ("includes[]", "cover_art"),
            ("includes[]", "author"),
            ("includes[]", "artist"),
            ("order[relevance]", "desc"),
        ]
        payload = self._request("GET", f"{API_BASE}/manga", params=params).json()
        return [self._normalize_manga(item) for item in payload.get("data", [])]

    def get(self, manga_id: str) -> dict[str, Any]:
        params = [
            ("includes[]", "cover_art"),
            ("includes[]", "author"),
            ("includes[]", "artist"),
        ]
        payload = self._request("GET", f"{API_BASE}/manga/{manga_id}", params=params).json()
        manga = payload.get("data")
        if not isinstance(manga, dict):
            raise MangaDexError("MangaDex did not return a manga record")
        normalized = self._normalize_manga(manga)
        normalized["refreshed_at"] = int(time.time())
        save_json(METADATA_DIR / f"{manga_id}.json", normalized)
        return normalized

    def download_cover(self, metadata: dict[str, Any], size: int = 512) -> str:
        cover = metadata.get("cover") or {}
        manga_id = metadata.get("id", "")
        filename = cover.get("filename", "") if isinstance(cover, dict) else ""
        if not manga_id or not filename:
            return ""
        suffix = f".{size}.jpg" if size in {256, 512} else ""
        url = f"{UPLOADS_BASE}/covers/{manga_id}/{filename}{suffix}"
        target = COVERS_DIR / f"{manga_id}.jpg"
        response = self._request("GET", url, stream=True)
        temp = target.with_suffix(".tmp")
        with temp.open("wb") as handle:
            for chunk in response.iter_content(chunk_size=1024 * 128):
                if chunk:
                    handle.write(chunk)
        temp.replace(target)
        return str(target)

    def _normalize_manga(self, item: dict[str, Any]) -> dict[str, Any]:
        attributes = item.get("attributes") or {}
        relationships = item.get("relationships") or []
        authors: list[str] = []
        artists: list[str] = []
        cover: dict[str, str] = {}

        for rel in relationships:
            rel_type = rel.get("type")
            rel_attrs = rel.get("attributes") or {}
            if rel_type == "author":
                name = rel_attrs.get("name")
                if name and name not in authors:
                    authors.append(name)
            elif rel_type == "artist":
                name = rel_attrs.get("name")
                if name and name not in artists:
                    artists.append(name)
            elif rel_type == "cover_art":
                filename = rel_attrs.get("fileName")
                if filename:
                    cover = {
                        "id": rel.get("id", ""),
                        "filename": filename,
                        "volume": str(rel_attrs.get("volume") or ""),
                        "locale": str(rel_attrs.get("locale") or ""),
                    }

        title_map = attributes.get("title") or {}
        alt_title_maps = attributes.get("altTitles") or []
        description_map = attributes.get("description") or {}
        main_title = self._localized_value(title_map)
        original_language = attributes.get("originalLanguage") or ""
        original_title = title_map.get(original_language) or main_title
        alt_titles: list[str] = []
        for alt in alt_title_maps:
            if not isinstance(alt, dict):
                continue
            value = self._localized_value(alt)
            if value and value not in alt_titles and value != main_title:
                alt_titles.append(value)

        tags = []
        for tag in attributes.get("tags") or []:
            name_map = (tag.get("attributes") or {}).get("name") or {}
            name = self._localized_value(name_map)
            if name:
                tags.append(name)

        links = attributes.get("links") or {}
        external_links = self._normalize_links(links)
        manga_id = item.get("id", "")
        return {
            "id": manga_id,
            "title": main_title,
            "original_title": original_title,
            "alt_titles": alt_titles,
            "description": self._localized_value(description_map),
            "authors": authors,
            "artists": artists,
            "status": attributes.get("status") or "",
            "year": attributes.get("year"),
            "publication_demographic": attributes.get("publicationDemographic") or "",
            "content_rating": attributes.get("contentRating") or "",
            "original_language": original_language,
            "last_volume": attributes.get("lastVolume") or "",
            "last_chapter": attributes.get("lastChapter") or "",
            "tags": tags,
            "links": external_links,
            "cover": cover,
            "mangadex_url": f"https://mangadex.org/title/{manga_id}" if manga_id else "",
        }

    def _localized_value(self, mapping: Any) -> str:
        if not isinstance(mapping, dict):
            return ""
        preferred = mapping.get(self.preferred_language)
        if preferred:
            return str(preferred)
        english = mapping.get("en")
        if english:
            return str(english)
        for value in mapping.values():
            if value:
                return str(value)
        return ""

    @staticmethod
    def _normalize_links(links: Any) -> dict[str, str]:
        if not isinstance(links, dict):
            return {}
        result: dict[str, str] = {}
        mapping = {
            "mu": ("MangaUpdates", "https://www.mangaupdates.com/series/"),
            "raw": ("Official Raw", ""),
            "engtl": ("Official English", ""),
            "mal": ("MyAnimeList", "https://myanimelist.net/manga/"),
            "al": ("AniList", "https://anilist.co/manga/"),
            "ap": ("Anime-Planet", "https://www.anime-planet.com/manga/"),
            "kt": ("Kitsu", "https://kitsu.io/manga/"),
            "bw": ("BookWalker", "https://bookwalker.jp/"),
            "amz": ("Amazon", ""),
            "ebj": ("ebookjapan", ""),
            "nu": ("NovelUpdates", "https://www.novelupdates.com/series/"),
            "cdj": ("CDJapan", "https://www.cdjapan.co.jp/"),
        }
        for key, value in links.items():
            if not value or key not in mapping:
                # MangaDex occasionally returns new or nonstandard codes. Do
                # not expose raw codes such as ``bl`` until deliberately mapped.
                continue
            label, prefix = mapping[key]
            text = str(value).strip()
            if prefix and not text.startswith(("http://", "https://")):
                text = prefix + text.lstrip("/")
            if text.startswith(("http://", "https://", "mailto:")):
                result[label] = text
        return result


def load_cached_metadata(manga_id: str) -> dict[str, Any]:
    if not manga_id:
        return {}
    return load_json(METADATA_DIR / f"{manga_id}.json", {})
